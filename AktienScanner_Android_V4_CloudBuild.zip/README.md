# Aktien Scanner Android – Cloud Build V4

Android-App + Scanner-API + News-Endpunkt + Cloud-APK-Build.

Der GitHub Actions Workflow baut automatisch eine Release-APK.
