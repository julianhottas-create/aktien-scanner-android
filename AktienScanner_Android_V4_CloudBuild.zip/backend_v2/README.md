# Online deployment

## Render
This backend is configured for a Render Web Service.

Build:
`pip install -r requirements.txt`

Start:
`uvicorn api_server:app --host 0.0.0.0 --port $PORT`

Health:
`GET /health`

After deployment, the API receives an `https://...onrender.com` URL.

## Important
The free Render service is suitable for testing. Free services can sleep after inactivity,
so the first request after idle time can be slower. For a continuously responsive scanner,
a paid compute service is more appropriate.
