Android-Konfiguration für den Aktien Scanner. Für einen echten APK-Build muss dieses Projekt mit Flutter/Android SDK gebaut werden.
