# Aktien Scanner – API V1

Diese Version ist der erste headless Schritt der Android-App.

## Endpunkte

- GET `/health` – Serverstatus
- GET `/markets` – verfügbare Märkte
- POST `/scan` – kompletter Scan mit deiner V8-Scanlogik
- GET `/last-scan` – letzter Scan

## Start

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Android-Terminal:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn api_server:app --host 0.0.0.0 --port 8000
```

## Wichtig

Die API führt die bestehende V8-Logik headless aus: Kursdaten-Batch, technische Analyse,
Fundamentaldaten und Market Intelligence. News bleiben bewusst separat und werden im
normalen Scan nicht geladen – entsprechend deiner bisherigen Scanner-Regel.

Die Android-App wird in Schritt 3 direkt diese API ansprechen.
