import os
import math
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import io
import requests
import plotly.graph_objects as go
import yfinance as yf
from plotly.subplots import make_subplots
RSI_PERIOD = 14
ATR_PERIOD = 14
SCAN_DOWNLOAD_WORKERS = 8
SCAN_INDICATOR_WORKERS = 8
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
ADX_PERIOD = 14
NEWS_LOOKBACK = 12
NEWS_SCORE_MAX = 20
COMPANY_NEWS_POINTS = 10
SECTOR_NEWS_POINTS = 5
GLOBAL_NEWS_POINTS = 5
NEWS_CACHE_TTL = 600
GLOBAL_NEWS_CACHE_TTL = 900
EARNINGS_CACHE_TTL = 1800
RELATIVE_STRENGTH_CACHE_TTL = 1800
EARNINGS_RISK_DAYS = 3
DEFAULT_BENCHMARK = 'SPY'
NEWS_MAX_ARTICLES_PER_SOURCE = 10
DATA_DIR = 'trading_data'
JOURNAL_FILE = os.path.join(DATA_DIR, 'trading_journal.csv')
UNIVERSE_CACHE_TTL = 6 * 60 * 60

def _web_tables(url):
    """Lädt HTML-Tabellen robust mit Browser-Headern."""
    response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/139 Safari/537.36', 'Accept-Language': 'en-US,en;q=0.9,de;q=0.8'}, timeout=25)
    response.raise_for_status()
    return pd.read_html(io.StringIO(response.text))

def _flat_columns(df):
    """Normalisiert normale und MultiIndex-Spaltennamen aus Wikipedia."""
    out = []
    for col in df.columns:
        if isinstance(col, tuple):
            parts = [str(x).strip() for x in col if str(x).strip().lower() != 'nan']
            out.append(' '.join(parts).strip().lower())
        else:
            out.append(str(col).strip().lower())
    return out

def _find_column(df, candidates):
    cols = _flat_columns(df)
    for candidate in candidates:
        for idx, col in enumerate(cols):
            if col == candidate or candidate in col:
                return df.columns[idx]
    return None

def _load_nasdaq100():
    urls = ['https://en.wikipedia.org/wiki/List_of_NASDAQ-100_companies', 'https://de.wikipedia.org/wiki/Liste_der_Unternehmen_im_Nasdaq-100']
    last_error = None
    for url in urls:
        try:
            tables = _web_tables(url)
            for df in tables:
                col = _find_column(df, ('ticker', 'symbol'))
                if col is None:
                    continue
                vals = []
                for value in df[col].astype(str):
                    for v in re.split('[,/;]', value):
                        v = v.strip().upper()
                        if re.fullmatch('[A-Z][A-Z0-9.-]{0,7}', v):
                            vals.append(v)
                vals = list(dict.fromkeys(vals))
                if len(vals) >= 80:
                    return vals
            last_error = ValueError('Nasdaq-100-Tabelle ohne verwertbare Ticker-Spalte.')
        except Exception as exc:
            last_error = exc
    raise ValueError(f'Nasdaq-100 konnte nicht geladen werden: {last_error}')

def _load_sp500():
    tables = _web_tables('https://en.wikipedia.org/wiki/List_of_S%26P_500_companies')
    for df in tables:
        col = _find_column(df, ('symbol', 'ticker'))
        if col is None:
            continue
        vals = [str(v).strip().upper().replace('.', '-') for v in df[col].tolist()]
        vals = [v for v in vals if re.fullmatch('[A-Z][A-Z0-9-]{0,7}', v)]
        if len(vals) >= 450:
            return list(dict.fromkeys(vals))
    raise ValueError('S&P-500-Tabelle konnte nicht erkannt werden.')

def _load_dax():
    tables = _web_tables('https://de.wikipedia.org/wiki/DAX')
    for df in tables:
        col = _find_column(df, ('symbol', 'ticker', 'symbol/ticker'))
        if col is None:
            continue
        vals = [str(v).strip().upper() for v in df[col].tolist()]
        vals = [v for v in vals if re.fullmatch('[A-Z0-9][A-Z0-9.-]{0,9}', v)]
        if len(vals) >= 30:
            return [v + '.DE' if '.' not in v else v for v in dict.fromkeys(vals)]
    raise ValueError('DAX-Tabelle konnte nicht erkannt werden.')
COUNTRY_SUFFIX = {'United Kingdom': '.L', 'Great Britain': '.L', 'UK': '.L', 'Switzerland': '.SW', 'France': '.PA', 'Germany': '.DE', 'Netherlands': '.AS', 'Spain': '.MC', 'Italy': '.MI', 'Sweden': '.ST', 'Denmark': '.CO', 'Norway': '.OL', 'Finland': '.HE', 'Belgium': '.BR', 'Austria': '.VI', 'Portugal': '.LS', 'Ireland': '.IR', 'Poland': '.WA'}

def _load_europe600():
    urls = ['https://en.wikipedia.org/wiki/STOXX_Europe_600', 'https://de.wikipedia.org/wiki/STOXX_Europe_600']
    last_error = None
    for url in urls:
        try:
            tables = _web_tables(url)
            for df in tables:
                ticker_col = _find_column(df, ('ticker', 'symbol'))
                if ticker_col is None:
                    continue
                country_col = _find_column(df, ('country', 'land'))
                out = []
                for _, row in df.iterrows():
                    raw = str(row.get(ticker_col, '')).strip().upper()
                    country = str(row.get(country_col, '')).strip() if country_col is not None else ''
                    if not raw or raw.lower() == 'nan':
                        continue
                    raw = raw.replace(' ', '-').replace("'", '')
                    raw = re.split('[,/;]', raw)[0].strip()
                    if not re.fullmatch('[A-Z0-9][A-Z0-9.-]{0,11}', raw):
                        continue
                    if '.' not in raw and country in COUNTRY_SUFFIX:
                        raw += COUNTRY_SUFFIX[country]
                    out.append(raw)
                out = list(dict.fromkeys(out))
                if len(out) >= 450:
                    return out
            last_error = ValueError('STOXX-Europe-600-Tabelle ohne ausreichend verwertbare Ticker.')
        except Exception as exc:
            last_error = exc
    raise ValueError(f'STOXX Europe 600 konnte nicht geladen werden: {last_error}')

def _load_crypto100():
    url = 'https://api.coingecko.com/api/v3/coins/markets'
    response = requests.get(url, params={'vs_currency': 'usd', 'order': 'market_cap_desc', 'per_page': 100, 'page': 1, 'sparkline': 'false'}, headers={'User-Agent': 'Mozilla/5.0 SwingTradingCommandCenter/1.0'}, timeout=20)
    response.raise_for_status()
    data = response.json()
    return [str(x.get('symbol', '')).upper() + '-USD' for x in data if x.get('symbol')]

def get_market_universe(selected_markets):
    """Lädt das ausgewählte Universum. Nur Tickerlisten, keine Kursanalyse."""
    fallback = {k: list(v) for k, v in MARKETS.items()}
    loaders = {'🇺🇸 US Tech': _load_nasdaq100, '🇺🇸 US Standard': _load_sp500, '🇩🇪 Deutschland': _load_dax, '🇪🇺 Europa': _load_europe600, '🪙 Krypto': _load_crypto100}
    loaded = {}
    errors = []
    for market in selected_markets:
        try:
            values = loaders[market]()
            loaded[market] = list(dict.fromkeys(values))
        except Exception as exc:
            loaded[market] = fallback.get(market, [])
            errors.append(f'{market}: dynamisches Laden fehlgeschlagen ({exc}); Fallback verwendet.')
    return (loaded, errors)
MARKETS = {'🇺🇸 US Tech': ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX', 'AMD', 'INTC', 'AVGO', 'CSCO', 'ORCL', 'CRM', 'ADBE', 'QCOM', 'TXN', 'MU', 'AMAT', 'ADI'], '🇺🇸 US Standard': ['JPM', 'BAC', 'WFC', 'C', 'GS', 'MS', 'BLK', 'AXP', 'V', 'MA', 'XOM', 'CVX', 'CAT', 'DE', 'GE', 'HON', 'LMT', 'RTX', 'BA', 'WMT'], '🇩🇪 Deutschland': ['ADS.DE', 'ALV.DE', 'BAS.DE', 'BAYN.DE', 'BMW.DE', 'CON.DE', '1COV.DE', 'DTG.DE', 'DB1.DE', 'DBK.DE', 'DHL.DE', 'DTE.DE', 'EOAN.DE', 'FRE.DE', 'HNR1.DE', 'HEI.DE', 'HEN3.DE', 'IFX.DE', 'MBG.DE', 'MRK.DE', 'SAP.DE', 'SIE.DE', 'VOW3.DE', 'RHM.DE'], '🇪🇺 Europa': ['ASML', 'MC.PA', 'OR.PA', 'RMS.PA', 'KER.PA', 'TTE.PA', 'SAN.PA', 'SU.PA', 'BNP.PA', 'AIR.PA', 'INGA.AS', 'BBVA.MC', 'SAN.MC', 'NESN.SW', 'NOVN.SW'], '🪙 Krypto': ['BTC-USD', 'ETH-USD', 'SOL-USD', 'BNB-USD', 'XRP-USD', 'ADA-USD']}

def safe_float(value, default=np.nan):
    try:
        value = float(value)
        if np.isfinite(value):
            return value
        return default
    except Exception:
        return default

def fmt_price(value):
    if pd.isna(value):
        return '-'
    return f'{float(value):.2f}'

def fmt_money(value):
    if pd.isna(value):
        return '-'
    return f'€ {float(value):,.2f}'

def score_color(score):
    if score >= 80:
        return '#255dcc'
    if score >= 65:
        return '#2f6fed'
    if score >= 50:
        return '#6b7c90'
    return '#91a1b4'

def signal_badge(direction):
    if direction == 'LONG':
        return '<span class="signal signal-long">▲ LONG</span>'
    if direction == 'SHORT':
        return '<span class="signal signal-short">▼ SHORT</span>'
    return '<span class="signal signal-neutral">• NEUTRAL</span>'

def setup_grade(score):
    if score >= 85:
        return '🔥 A+'
    if score >= 70:
        return '🔵 A'
    if score >= 55:
        return '⚪ B'
    if score >= 40:
        return '◽ WATCHLIST'
    return '— NO TRADE'

def clean_yfinance_data(raw):
    if raw is None or raw.empty:
        return None
    df = raw.copy()
    if isinstance(df.columns, pd.MultiIndex):
        flattened = {}
        for col in df.columns:
            if not isinstance(col, tuple):
                continue
            field = None
            for item in col:
                if str(item) in {'Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume'}:
                    field = str(item)
                    break
            if field and field not in flattened:
                flattened[field] = col
        if flattened:
            df = df[list(flattened.values())].copy()
            df.columns = list(flattened.keys())
        else:
            try:
                df.columns = df.columns.get_level_values(0)
            except Exception:
                return None
    df.columns = [str(column).strip() for column in df.columns]
    df = df.loc[:, ~df.columns.duplicated()]
    required = ['Open', 'High', 'Low', 'Close']
    for column in required:
        if column not in df.columns:
            return None
        df[column] = pd.to_numeric(df[column], errors='coerce')
    if 'Volume' not in df.columns:
        df['Volume'] = 0
    df['Volume'] = pd.to_numeric(df['Volume'], errors='coerce').fillna(0)
    df = df.dropna(subset=required)
    if df.empty:
        return None
    try:
        df.index = pd.to_datetime(df.index)
        if getattr(df.index, 'tz', None) is not None:
            df.index = df.index.tz_localize(None)
    except Exception:
        pass
    return df.sort_index()

def calculate_rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    rsi = rsi.mask((avg_loss == 0) & (avg_gain > 0), 100)
    rsi = rsi.mask((avg_gain == 0) & (avg_loss > 0), 0)
    return rsi

def calculate_atr(df, period=14):
    high_low = df['High'] - df['Low']
    high_close = (df['High'] - df['Close'].shift(1)).abs()
    low_close = (df['Low'] - df['Close'].shift(1)).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()

def calculate_macd(close, fast=MACD_FAST, slow=MACD_SLOW, signal=MACD_SIGNAL):
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    return (macd, signal_line, histogram)

def macd_crossover(df, direction):
    if df is None or len(df) < MACD_SLOW + MACD_SIGNAL + 2:
        return False
    macd = df['MACD']
    signal = df['MACDSignal']
    if any((pd.isna(x) for x in [macd.iloc[-2], macd.iloc[-1], signal.iloc[-2], signal.iloc[-1]])):
        return False
    if direction == 'LONG':
        return macd.iloc[-2] <= signal.iloc[-2] and macd.iloc[-1] > signal.iloc[-1]
    if direction == 'SHORT':
        return macd.iloc[-2] >= signal.iloc[-2] and macd.iloc[-1] < signal.iloc[-1]
    return False

def calculate_adx(df, period=ADX_PERIOD):
    if df is None or len(df) < period * 2 + 2:
        return pd.Series(index=df.index, dtype=float) if df is not None else pd.Series(dtype=float)
    high = df['High']
    low = df['Low']
    close = df['Close']
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
    minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
    tr = pd.concat([high - low, (high - close.shift(1)).abs(), (low - close.shift(1)).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    plus_di = 100 * plus_dm.ewm(alpha=1 / period, adjust=False, min_periods=period).mean() / atr.replace(0, np.nan)
    minus_di = 100 * minus_dm.ewm(alpha=1 / period, adjust=False, min_periods=period).mean() / atr.replace(0, np.nan)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    return dx.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()

def adx_confirmation(df, direction, minimum=20):
    if df is None or df.empty or 'ADX' not in df.columns:
        return False
    adx = safe_float(df['ADX'].iloc[-1])
    if np.isnan(adx) or adx < minimum:
        return False
    return True

def atr_regime_confirmation(df, min_pct=0.01, max_pct=0.06):
    if df is None or df.empty or 'ATR' not in df.columns:
        return False
    close = safe_float(df['Close'].iloc[-1])
    atr = safe_float(df['ATR'].iloc[-1])
    if np.isnan(close) or np.isnan(atr) or close <= 0:
        return False
    atr_pct = atr / close
    return min_pct <= atr_pct <= max_pct

def candle_confirmation(df, direction, lookback=20):
    if df is None or len(df) < lookback + 2:
        return False
    row = df.iloc[-1]
    prev = df.iloc[-2]
    o = safe_float(row['Open'])
    h = safe_float(row['High'])
    l = safe_float(row['Low'])
    c = safe_float(row['Close'])
    if any((np.isnan(x) for x in [o, h, l, c])):
        return False
    body = abs(c - o)
    rng = max(h - l, 1e-12)
    body_ratio = body / rng
    previous = df.iloc[-(lookback + 1):-1]
    if direction == 'LONG':
        level = safe_float(previous['High'].max())
        upper_wick = h - max(o, c)
        return c > level and c > o and (body_ratio >= 0.45) and (upper_wick / rng <= 0.35)
    if direction == 'SHORT':
        level = safe_float(previous['Low'].min())
        lower_wick = min(o, c) - l
        return c < level and c < o and (body_ratio >= 0.45) and (lower_wick / rng <= 0.35)
    return False

def entry_distance_confirmation(df, direction, max_atr_distance=1.0):
    if df is None or df.empty or 'ATR' not in df.columns:
        return False
    close = safe_float(df['Close'].iloc[-1])
    ema20 = safe_float(df['EMA20'].iloc[-1])
    atr = safe_float(df['ATR'].iloc[-1])
    if any((np.isnan(x) for x in [close, ema20, atr])) or atr <= 0:
        return False
    return abs(close - ema20) <= atr * max_atr_distance

def reward_risk_confirmation(plan, minimum_rr=2.0):
    if not plan:
        return False
    rr = safe_float(plan.get('crv_tp1'))
    return not np.isnan(rr) and rr >= minimum_rr

def room_to_target_confirmation(plan, direction, minimum_rr=2.0):
    if not plan:
        return False
    entry = safe_float(plan.get('entry'))
    stop = safe_float(plan.get('stop'))
    support = safe_float(plan.get('support'))
    resistance = safe_float(plan.get('resistance'))
    if any((np.isnan(x) for x in [entry, stop])):
        return False
    risk = abs(entry - stop)
    if risk <= 0:
        return False
    if direction == 'LONG':
        if np.isnan(resistance) or resistance <= entry:
            return True
        return (resistance - entry) / risk >= minimum_rr
    if direction == 'SHORT':
        if np.isnan(support) or support >= entry:
            return True
        return (entry - support) / risk >= minimum_rr
    return False

def add_indicators(df):
    if df is None or df.empty:
        return None
    df = df.copy()
    close = df['Close']
    df['SMA20'] = close.rolling(20, min_periods=20).mean()
    df['SMA50'] = close.rolling(50, min_periods=50).mean()
    df['SMA200'] = close.rolling(200, min_periods=200).mean()
    df['EMA20'] = close.ewm(span=20, adjust=False).mean()
    df['RSI'] = calculate_rsi(close, RSI_PERIOD)
    df['MACD'], df['MACDSignal'], df['MACDHistogram'] = calculate_macd(close)
    df['ATR'] = calculate_atr(df, ATR_PERIOD)
    df['ADX'] = calculate_adx(df, ADX_PERIOD)
    df['VolumeMA20'] = df['Volume'].rolling(20, min_periods=20).mean()
    df['Return'] = close.pct_change()
    return df

def download_daily(ticker):
    try:
        raw = yf.download(ticker, period='5y', interval='1d', auto_adjust=False, progress=False, threads=False)
        df = clean_yfinance_data(raw)
        if df is None:
            return None
        return add_indicators(df)
    except Exception:
        return None

def _extract_ticker_frame(raw, ticker):
    """Extrahiert einen einzelnen Ticker aus yf.download(group_by='ticker')."""
    if raw is None or raw.empty:
        return None
    try:
        if not isinstance(raw.columns, pd.MultiIndex):
            return raw.copy()
        cols = raw.columns
        ticker_text = str(ticker).upper()
        for level in range(cols.nlevels):
            values = [str(v).upper() for v in cols.get_level_values(level)]
            if ticker_text in values:
                mask = [str(v).upper() == ticker_text for v in cols.get_level_values(level)]
                out = raw.loc[:, mask].copy()
                if isinstance(out.columns, pd.MultiIndex):
                    new_cols = []
                    for col in out.columns:
                        remaining = [str(x) for i, x in enumerate(col) if i != level]
                        new_cols.append(remaining[0] if len(remaining) == 1 else remaining[-1])
                    out.columns = new_cols
                return out
    except Exception:
        return None
    return None

def _calculate_indicators_for_item(item):
    """Berechnet exakt dieselben Indikatoren wie bisher, aber parallel pro Aktie."""
    ticker, df = item
    if df is None:
        return (ticker, None)
    try:
        return (ticker, add_indicators(df))
    except Exception:
        return (ticker, None)

def _add_indicators_parallel(frames):
    """Parallelisiert ausschließlich die CPU-/Pandas-Indikatorberechnung."""
    result = {}
    items = list(frames.items())
    if not items:
        return result
    workers = max(1, min(SCAN_INDICATOR_WORKERS, len(items), os.cpu_count() or 1))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        for ticker, df in executor.map(_calculate_indicators_for_item, items):
            result[ticker] = df
    return result

def download_daily_batch(tickers, chunk_size=60):
    """Lädt Tagesdaten blockweise und berechnet die Indikatoren parallel."""
    tickers = tuple(dict.fromkeys((str(t) for t in tickers if t)))
    raw_frames = {}
    for start in range(0, len(tickers), int(chunk_size)):
        chunk = list(tickers[start:start + int(chunk_size)])
        try:
            raw = yf.download(tickers=chunk, period='5y', interval='1d', auto_adjust=False, progress=False, threads=True, group_by='ticker')
            for ticker in chunk:
                one = _extract_ticker_frame(raw, ticker)
                raw_frames[ticker] = clean_yfinance_data(one)
        except Exception:
            for ticker in chunk:
                raw_frames[ticker] = download_daily(ticker)
    return _add_indicators_parallel(raw_frames)

def download_intraday_batch(tickers, chunk_size=50):
    """Lädt 1H-Daten blockweise und berechnet die Indikatoren parallel."""
    tickers = tuple(dict.fromkeys((str(t) for t in tickers if t)))
    raw_frames = {}
    for start in range(0, len(tickers), int(chunk_size)):
        chunk = list(tickers[start:start + int(chunk_size)])
        try:
            raw = yf.download(tickers=chunk, period='60d', interval='1h', auto_adjust=False, progress=False, threads=True, group_by='ticker')
            for ticker in chunk:
                one = _extract_ticker_frame(raw, ticker)
                raw_frames[ticker] = clean_yfinance_data(one)
        except Exception:
            for ticker in chunk:
                raw_frames[ticker] = download_intraday(ticker)
    return _add_indicators_parallel(raw_frames)

def load_all_timeframes_batch(tickers):
    """Batch-Laden; Indikatorberechnung bleibt exakt dieselbe wie zuvor."""
    daily_map = download_daily_batch(tickers)
    intraday_map = download_intraday_batch(tickers)
    result = {}
    for ticker in tickers:
        daily = daily_map.get(ticker)
        if daily is None:
            result[ticker] = None
            continue
        intraday = intraday_map.get(ticker)
        result[ticker] = {'Weekly': resample_weekly(daily), 'Daily': daily, '4H': make_4h_from_1h(intraday), '1H': intraday}
    return result

def download_intraday(ticker):
    try:
        raw = yf.download(ticker, period='60d', interval='1h', auto_adjust=False, progress=False, threads=False)
        df = clean_yfinance_data(raw)
        if df is None:
            return None
        return add_indicators(df)
    except Exception:
        return None

def make_4h_from_1h(df):
    if df is None or df.empty:
        return None
    result = df[['Open', 'High', 'Low', 'Close', 'Volume']].resample('4h').agg({'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum'}).dropna(subset=['Open', 'High', 'Low', 'Close'])
    if result.empty:
        return None
    return add_indicators(result)

def resample_weekly(df):
    if df is None or df.empty:
        return None
    weekly = df[['Open', 'High', 'Low', 'Close', 'Volume']].resample('W-FRI').agg({'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum'}).dropna(subset=['Open', 'High', 'Low', 'Close'])
    if weekly.empty:
        return None
    return add_indicators(weekly)

def load_all_timeframes(ticker):
    daily = download_daily(ticker)
    if daily is None:
        return None
    intraday = download_intraday(ticker)
    return {'Weekly': resample_weekly(daily), 'Daily': daily, '4H': make_4h_from_1h(intraday), '1H': intraday}

def find_swing_points(df, window=3):
    if df is None:
        return ([], [])
    if len(df) < 2 * window + 5:
        return ([], [])
    highs = []
    lows = []
    high_values = df['High'].values
    low_values = df['Low'].values
    for i in range(window, len(df) - window):
        current_high = high_values[i]
        left_high = high_values[i - window:i]
        right_high = high_values[i + 1:i + window + 1]
        if current_high >= left_high.max() and current_high >= right_high.max():
            highs.append(i)
        current_low = low_values[i]
        left_low = low_values[i - window:i]
        right_low = low_values[i + 1:i + window + 1]
        if current_low <= left_low.min() and current_low <= right_low.min():
            lows.append(i)
    return (highs, lows)

def market_structure(df):
    if df is None or len(df) < 30:
        return {'direction': 'NEUTRAL', 'score': 0, 'swing_highs': [], 'swing_lows': []}
    highs, lows = find_swing_points(df, window=3)
    score = 0
    if len(highs) >= 2:
        last_high = safe_float(df['High'].iloc[highs[-1]])
        previous_high = safe_float(df['High'].iloc[highs[-2]])
        if last_high > previous_high:
            score += 1
        elif last_high < previous_high:
            score -= 1
    if len(lows) >= 2:
        last_low = safe_float(df['Low'].iloc[lows[-1]])
        previous_low = safe_float(df['Low'].iloc[lows[-2]])
        if last_low > previous_low:
            score += 1
        elif last_low < previous_low:
            score -= 1
    if score >= 2:
        direction = 'BULLISH'
    elif score <= -2:
        direction = 'BEARISH'
    else:
        direction = 'NEUTRAL'
    return {'direction': direction, 'score': score, 'swing_highs': highs, 'swing_lows': lows}

def trend_analysis(df):
    if df is None or len(df) < 50:
        return {'trend': 'NEUTRAL', 'score': 0}
    row = df.iloc[-1]
    close = safe_float(row['Close'])
    sma50 = safe_float(row['SMA50'])
    sma200 = safe_float(row['SMA200'])
    score = 0
    if not np.isnan(sma50):
        score += 1 if close > sma50 else -1
    if not np.isnan(sma200):
        score += 1 if close > sma200 else -1
    if not np.isnan(sma50) and (not np.isnan(sma200)):
        score += 1 if sma50 > sma200 else -1
    if score >= 2:
        trend = 'BULLISH'
    elif score <= -2:
        trend = 'BEARISH'
    else:
        trend = 'NEUTRAL'
    return {'trend': trend, 'score': score}

def detect_pullback(df, direction):
    if df is None or len(df) < 50:
        return False
    row = df.iloc[-1]
    close = safe_float(row['Close'])
    ema20 = safe_float(row['EMA20'])
    sma50 = safe_float(row['SMA50'])
    if any((np.isnan(x) for x in [close, ema20, sma50])):
        return False
    distance = abs(close - ema20) / close
    if direction == 'LONG':
        return distance <= 0.04 and close > sma50
    if direction == 'SHORT':
        return distance <= 0.04 and close < sma50
    return False

def detect_breakout(df, direction, lookback=20):
    if df is None:
        return False
    if len(df) < lookback + 2:
        return False
    previous = df.iloc[-(lookback + 1):-1]
    current_close = safe_float(df['Close'].iloc[-1])
    if np.isnan(current_close):
        return False
    if direction == 'LONG':
        resistance = safe_float(previous['High'].max())
        return not np.isnan(resistance) and current_close > resistance
    if direction == 'SHORT':
        support = safe_float(previous['Low'].min())
        return not np.isnan(support) and current_close < support
    return False

def volume_confirmation(df):
    if df is None or len(df) < 20:
        return False
    row = df.iloc[-1]
    volume = safe_float(row['Volume'])
    average = safe_float(row['VolumeMA20'])
    if np.isnan(volume) or np.isnan(average) or average <= 0:
        return False
    return volume >= average * 1.2

def momentum_analysis(df, direction):
    if df is None or len(df) < 30:
        return (False, 0)
    row = df.iloc[-1]
    rsi = safe_float(row['RSI'])
    close = safe_float(row['Close'])
    ema20 = safe_float(row['EMA20'])
    score = 0
    if direction == 'LONG':
        if not np.isnan(rsi) and 50 <= rsi <= 72:
            score += 1
        if not np.isnan(close) and (not np.isnan(ema20)) and (close > ema20):
            score += 1
    elif direction == 'SHORT':
        if not np.isnan(rsi) and 28 <= rsi <= 50:
            score += 1
        if not np.isnan(close) and (not np.isnan(ema20)) and (close < ema20):
            score += 1
    return (score >= 1, score)
POSITIVE_NEWS_TERMS = {'beats', 'beat', 'strong results', 'record revenue', 'record profit', 'raises guidance', 'raised guidance', 'upgrade', 'upgraded', 'buy rating', 'partnership', 'contract win', 'new contract', 'approval', 'approved', 'breakthrough', 'expands', 'expansion', 'growth', 'acquisition', 'acquires', 'positive outlook', 'strong demand', 'surge', 'wins', 'launches', 'rate cut', 'stimulus', 'ceasefire', 'deal', 'agreement', 'easing', 'lower inflation'}
NEGATIVE_NEWS_TERMS = {'misses', 'miss', 'weak results', 'cuts guidance', 'cut guidance', 'downgrade', 'downgraded', 'sell rating', 'lawsuit', 'investigation', 'probe', 'antitrust', 'recall', 'recalls', 'warning', 'layoffs', 'job cuts', 'bankruptcy', 'fraud', 'scandal', 'cyberattack', 'breach', 'decline', 'slump', 'weak demand', 'profit warning', 'negative outlook', 'tariff', 'sanctions', 'export ban', 'delay', 'delays', 'war', 'attack', 'invasion', 'conflict', 'rate hike', 'higher rates', 'inflation surge', 'recession', 'default', 'supply disruption', 'shortage'}
HIGH_IMPACT_TERMS = {'earnings', 'guidance', 'fda', 'regulator', 'regulatory', 'merger', 'acquisition', 'lawsuit', 'investigation', 'tariff', 'sanctions', 'export ban', 'contract', 'ceo', 'cfo', 'bankruptcy', 'recall', 'approval', 'central bank', 'federal reserve', 'ecb', 'interest rate', 'war', 'ceasefire', 'opec', 'oil', 'china', 'taiwan'}
NEWS_SEVERITY_TERMS = {'earnings', 'guidance', 'profit warning', 'bankruptcy', 'fraud', 'sanctions', 'export ban', 'export controls', 'tariff', 'recall', 'antitrust', 'investigation', 'lawsuit', 'regulatory', 'approval', 'central bank', 'interest rate', 'rate hike', 'rate cut', 'war', 'invasion', 'attack', 'ceasefire', 'default', 'supply disruption', 'shutdown', 'strike', 'layoffs', 'merger', 'acquisition'}
NEWS_SOURCE_WEIGHTS = {'reuters': 1.15, 'bloomberg': 1.15, 'financial times': 1.12, 'wall street journal': 1.12, 'cnbc': 1.08, 'associated press': 1.08, 'federal reserve': 1.18, 'ecb': 1.18, 'sec': 1.18, 'yahoo finance': 1.0, 'google news': 0.92}
GLOBAL_THEME_SECTOR_EFFECTS = {'rates': {'technology': -1.0, 'semiconductors': -1.0, 'banks': 0.8, 'financials': 0.6, 'consumer': -0.4, 'healthcare': -0.2}, 'trade': {'technology': -0.5, 'semiconductors': -1.0, 'autos': -0.9, 'industrials': -0.6, 'consumer': -0.5, 'energy': -0.2}, 'geopolitics': {'technology': -0.3, 'semiconductors': -0.7, 'autos': -0.5, 'industrials': -0.3, 'defense': 0.9, 'energy': 0.4, 'financials': -0.3}, 'energy': {'energy': 0.9, 'autos': -0.7, 'airlines': -0.9, 'industrials': -0.3, 'consumer': -0.4}, 'growth': {'technology': 0.4, 'semiconductors': 0.5, 'autos': 0.2, 'industrials': 0.5, 'consumer': 0.3, 'financials': 0.3}, 'markets': {'technology': -0.2, 'semiconductors': -0.3, 'financials': -0.3, 'consumer': -0.2, 'industrials': -0.2}}
TICKER_IMPACT_THEMES = {'NVDA': {'technology': 1.0, 'semiconductors': 1.2, 'trade': 1.2, 'rates': 0.8}, 'AMD': {'technology': 1.0, 'semiconductors': 1.2, 'trade': 1.1, 'rates': 0.8}, 'AAPL': {'technology': 0.8, 'trade': 0.8, 'growth': 0.8}, 'TSLA': {'technology': 0.7, 'autos': 1.2, 'trade': 1.1, 'growth': 0.8, 'energy': 0.4}, 'BMW.DE': {'autos': 1.2, 'trade': 1.1, 'growth': 0.9, 'energy': 0.4}, 'JPM': {'banks': 1.2, 'financials': 1.0, 'rates': 1.0, 'markets': 0.8}, 'BAC': {'banks': 1.2, 'financials': 1.0, 'rates': 1.0, 'markets': 0.8}, 'XOM': {'energy': 1.2, 'geopolitics': 0.8, 'growth': 0.6}, 'CVX': {'energy': 1.2, 'geopolitics': 0.8, 'growth': 0.6}}
THEME_KEYWORDS = {'rates': {'federal reserve', 'fed', 'ecb', 'interest rate', 'rate hike', 'rate cut', 'yield', 'bond yields', 'central bank'}, 'trade': {'tariff', 'tariffs', 'sanctions', 'export controls', 'export ban', 'trade war', 'china', 'us-china', 'customs'}, 'geopolitics': {'war', 'conflict', 'ceasefire', 'ukraine', 'russia', 'middle east', 'gaza', 'israel', 'iran', 'taiwan', 'attack', 'invasion'}, 'energy': {'oil', 'opec', 'natural gas', 'energy prices', 'crude', 'brent', 'wti'}, 'growth': {'recession', 'gdp', 'jobs', 'unemployment', 'consumer spending', 'growth outlook', 'slowdown'}, 'markets': {'stock market', 'credit markets', 'volatility', 'financial stability', 'risk-off', 'risk on', 'selloff', 'market rally'}}
TICKER_ALIASES = {'AAPL': ['apple', 'iphone', 'ipad'], 'MSFT': ['microsoft', 'azure'], 'GOOGL': ['alphabet', 'google', 'youtube'], 'AMZN': ['amazon', 'aws'], 'META': ['meta', 'facebook', 'instagram'], 'TSLA': ['tesla', 'musk'], 'NVDA': ['nvidia', 'gpu', 'cuda'], 'NFLX': ['netflix'], 'AMD': ['amd', 'advanced micro devices'], 'INTC': ['intel'], 'AVGO': ['broadcom'], 'CSCO': ['cisco'], 'ORCL': ['oracle'], 'CRM': ['salesforce'], 'ADBE': ['adobe'], 'QCOM': ['qualcomm'], 'TXN': ['texas instruments'], 'MU': ['micron', 'dram', 'nand'], 'AMAT': ['applied materials'], 'ADI': ['analog devices'], 'JPM': ['jpmorgan', 'jp morgan'], 'BAC': ['bank of america'], 'WFC': ['wells fargo'], 'C': ['citigroup', 'citi'], 'GS': ['goldman sachs'], 'MS': ['morgan stanley'], 'BLK': ['blackrock'], 'AXP': ['american express'], 'V': ['visa'], 'MA': ['mastercard'], 'XOM': ['exxon', 'exxon mobil'], 'CVX': ['chevron'], 'CAT': ['caterpillar'], 'DE': ['deere'], 'GE': ['ge aerospace', 'general electric'], 'HON': ['honeywell'], 'LMT': ['lockheed martin'], 'RTX': ['rtx', 'raytheon'], 'BA': ['boeing'], 'WMT': ['walmart'], 'ADS.DE': ['adidas'], 'ALV.DE': ['allianz'], 'BAS.DE': ['basf'], 'BAYN.DE': ['bayer'], 'BMW.DE': ['bmw'], 'CON.DE': ['continental'], '1COV.DE': ['covestro'], 'DTG.DE': ['dtag', 'deutsche telekom'], 'DB1.DE': ['deutsche boerse'], 'DBK.DE': ['deutsche bank'], 'DHL.DE': ['dhl', 'deutsche post'], 'DTE.DE': ['deutsche telekom'], 'EOAN.DE': ['eon'], 'FRE.DE': ['fresenius'], 'HNR1.DE': ['hannover re'], 'HEI.DE': ['heidelberg materials'], 'HEN3.DE': ['henkel'], 'IFX.DE': ['infineon'], 'MBG.DE': ['mercedes benz', 'mercedes'], 'MRK.DE': ['merck', 'msd'], 'SAP.DE': ['sap'], 'SIE.DE': ['siemens'], 'VOW3.DE': ['volkswagen', 'vw'], 'RHM.DE': ['rheinmetall'], 'ASML': ['asml', 'semiconductor equipment'], 'MC.PA': ['lvmh'], 'OR.PA': ['loreal', "l'oreal"], 'RMS.PA': ['hermes'], 'KER.PA': ['kering'], 'TTE.PA': ['totalenergies', 'total energies'], 'SAN.PA': ['sanofi'], 'SU.PA': ['schneider electric'], 'BNP.PA': ['bnp paribas'], 'AIR.PA': ['airbus'], 'INGA.AS': ['ing'], 'BBVA.MC': ['bbva'], 'SAN.MC': ['santander'], 'NESN.SW': ['nestle', 'nestlé'], 'NOVN.SW': ['novartis'], 'BTC-USD': ['bitcoin', 'btc', 'crypto'], 'ETH-USD': ['ethereum', 'ether', 'crypto'], 'SOL-USD': ['solana', 'sol', 'crypto'], 'BNB-USD': ['bnb', 'binance', 'crypto'], 'XRP-USD': ['xrp', 'ripple', 'crypto'], 'ADA-USD': ['cardano', 'ada', 'crypto']}
SECTOR_TERMS = {'AAPL': ['technology', 'consumer electronics', 'smartphone', 'semiconductor'], 'MSFT': ['software', 'cloud', 'ai', 'artificial intelligence'], 'GOOGL': ['technology', 'advertising', 'ai', 'cloud'], 'AMZN': ['ecommerce', 'retail', 'cloud', 'aws'], 'META': ['social media', 'advertising', 'ai'], 'TSLA': ['electric vehicles', 'ev', 'autos', 'battery'], 'NVDA': ['semiconductor', 'chips', 'ai', 'data center', 'gpu'], 'AMD': ['semiconductor', 'chips', 'ai', 'cpu'], 'INTC': ['semiconductor', 'chips', 'foundry'], 'AVGO': ['semiconductor', 'chips', 'networking'], 'QCOM': ['semiconductor', 'wireless', 'smartphone'], 'MU': ['memory chips', 'semiconductor', 'dram', 'nand'], 'AMAT': ['semiconductor equipment', 'chip equipment'], 'ADI': ['semiconductor', 'chips'], 'TXN': ['semiconductor', 'chips'], 'ASML': ['semiconductor equipment', 'chip equipment', 'lithography'], 'IFX.DE': ['semiconductor', 'chips', 'automotive'], 'SAP.DE': ['software', 'cloud', 'enterprise software'], 'ORCL': ['software', 'cloud', 'database'], 'CRM': ['software', 'cloud'], 'JPM': ['banks', 'banking', 'financials', 'interest rates'], 'BAC': ['banks', 'banking', 'financials', 'interest rates'], 'GS': ['investment banking', 'financials', 'interest rates'], 'MS': ['investment banking', 'financials', 'interest rates'], 'BLK': ['asset management', 'financials', 'bonds'], 'V': ['payments', 'consumer spending'], 'MA': ['payments', 'consumer spending'], 'XOM': ['oil', 'energy', 'opec'], 'CVX': ['oil', 'energy', 'opec'], 'TTE.PA': ['oil', 'energy', 'opec'], 'CAT': ['industrial', 'construction', 'infrastructure'], 'DE': ['agriculture', 'machinery', 'industrial'], 'LMT': ['defense', 'aerospace', 'geopolitics'], 'RTX': ['defense', 'aerospace', 'geopolitics'], 'BA': ['aerospace', 'airlines', 'defense'], 'RHM.DE': ['defense', 'aerospace', 'geopolitics'], 'BMW.DE': ['autos', 'electric vehicles', 'china', 'tariffs'], 'MBG.DE': ['autos', 'electric vehicles', 'china', 'tariffs'], 'VOW3.DE': ['autos', 'electric vehicles', 'china', 'tariffs'], 'AIR.PA': ['aerospace', 'aviation'], 'BAS.DE': ['chemicals', 'industrial', 'energy'], 'BAYN.DE': ['pharmaceuticals', 'chemicals', 'agriculture'], 'MRK.DE': ['pharmaceuticals', 'healthcare'], 'FRE.DE': ['healthcare', 'hospitals'], 'NOVN.SW': ['pharmaceuticals', 'healthcare'], 'SAN.PA': ['pharmaceuticals', 'healthcare'], 'WMT': ['retail', 'consumer spending', 'food'], 'MC.PA': ['luxury', 'consumer', 'china'], 'OR.PA': ['beauty', 'consumer', 'china'], 'RMS.PA': ['luxury', 'consumer', 'china'], 'NESN.SW': ['consumer staples', 'food', 'china'], 'ALV.DE': ['insurance', 'financials', 'bonds'], 'DBK.DE': ['banks', 'banking', 'financials', 'interest rates'], 'BNP.PA': ['banks', 'banking', 'financials', 'interest rates'], 'BBVA.MC': ['banks', 'banking', 'financials', 'interest rates'], 'SAN.MC': ['banks', 'banking', 'financials', 'interest rates'], 'BTC-USD': ['bitcoin', 'crypto', 'cryptocurrency', 'digital assets'], 'ETH-USD': ['ethereum', 'crypto', 'cryptocurrency', 'digital assets'], 'SOL-USD': ['solana', 'crypto', 'cryptocurrency', 'digital assets'], 'BNB-USD': ['binance', 'crypto', 'cryptocurrency', 'digital assets'], 'XRP-USD': ['ripple', 'crypto', 'cryptocurrency', 'digital assets'], 'ADA-USD': ['cardano', 'crypto', 'cryptocurrency', 'digital assets']}
GLOBAL_NEWS_QUERIES = {'rates_inflation': 'Federal Reserve OR ECB OR interest rates OR inflation OR central bank', 'trade_tariffs': 'tariffs OR sanctions OR export controls OR trade war OR China US Europe', 'geopolitics': 'geopolitics OR war OR conflict OR ceasefire OR Ukraine OR Middle East OR Taiwan', 'energy': 'oil OR OPEC OR natural gas OR energy prices', 'growth_recession': 'recession OR GDP OR jobs OR unemployment OR consumer spending', 'markets_risk': 'stock market OR bond yields OR credit markets OR volatility OR financial stability'}

def _news_timestamp(item):
    value = item.get('providerPublishTime') or item.get('published') or item.get('pubDate')
    try:
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(value)
        return pd.to_datetime(value).to_pydatetime().replace(tzinfo=None)
    except Exception:
        return datetime.now()

def _normalize_news_item(item):
    content = item.get('content', item) if isinstance(item, dict) else {}
    title = str(content.get('title') or item.get('title') or '').strip()
    summary = str(content.get('summary') or content.get('description') or item.get('summary') or item.get('description') or '').strip()
    provider = content.get('provider') or item.get('publisher') or item.get('provider') or 'Yahoo Finance'
    if isinstance(provider, dict):
        provider = provider.get('displayName') or provider.get('name') or 'Yahoo Finance'
    link = content.get('canonicalUrl') or content.get('clickThroughUrl') or item.get('link') or item.get('url') or ''
    if isinstance(link, dict):
        link = link.get('url') or ''
    published = _news_timestamp(content if content else item)
    return _translate_news_item({'title': title, 'summary': summary, 'provider': str(provider), 'url': str(link), 'published': published})

def fetch_ticker_news(ticker, count=NEWS_LOOKBACK):
    """Tickerbezogene News über yfinance/Yahoo Finance."""
    try:
        search = yf.Search(ticker, max_results=3, news_count=count, enable_fuzzy_query=False, raise_errors=False)
        raw = getattr(search, 'news', None) or []
        normalized, seen = ([], set())
        for item in raw:
            news_item = _normalize_news_item(item)
            key = news_item['title'].lower()
            if news_item['title'] and key not in seen:
                seen.add(key)
                normalized.append(news_item)
        return normalized[:count]
    except Exception:
        try:
            raw = yf.Ticker(ticker).get_news(count=count, tab='all') or []
            return [_normalize_news_item(item) for item in raw[:count]]
        except Exception:
            return []

def _strip_html(text):
    return re.sub('<[^>]+>', ' ', str(text or '')).replace('&amp;', '&').strip()

def translate_to_german(text):
    """Übersetzt Nachrichten automatisch ins Deutsche; bei Fehlern bleibt der Originaltext erhalten."""
    text = str(text or '').strip()
    if not text:
        return ''
    german_markers = [' der ', ' die ', ' das ', ' und ', ' von ', ' für ', ' mit ', ' ist ', ' sind ', ' nicht ', ' wird ', ' werden ', ' auf ']
    padded = f' {text.lower()} '
    if sum((marker in padded for marker in german_markers)) >= 2:
        return text
    try:
        import json
        chunks = [text[i:i + 1800] for i in range(0, len(text), 1800)]
        translated = []
        for chunk in chunks:
            url = 'https://translate.googleapis.com/translate_a/single?' + urllib.parse.urlencode({'client': 'gtx', 'sl': 'auto', 'tl': 'de', 'dt': 't', 'q': chunk})
            request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 SwingTradingCommandCenter/1.0'})
            with urllib.request.urlopen(request, timeout=6) as response:
                payload = response.read().decode('utf-8')
            data = json.loads(payload)
            translated.append(''.join((part[0] for part in data[0] or [] if part and part[0])))
        result = ' '.join((x.strip() for x in translated if x.strip())).strip()
        return result or text
    except Exception:
        return text

def _translate_news_item(item):
    """Behält Originaltexte für die Impact-Analyse und liefert deutsche Anzeigetexte."""
    item = dict(item or {})
    original_title = str(item.get('original_title') or item.get('title') or '').strip()
    original_summary = str(item.get('original_summary') or item.get('summary') or '').strip()
    item['original_title'] = original_title
    item['original_summary'] = original_summary
    item['title'] = translate_to_german(original_title) if original_title else ''
    item['summary'] = translate_to_german(original_summary) if original_summary else ''
    item['translated'] = item['title'] != original_title or item['summary'] != original_summary
    return item

def fetch_google_news_rss(query, count=NEWS_MAX_ARTICLES_PER_SOURCE):
    """Kostenloser RSS-Abruf. Kein API-Key nötig; Fehler führen zu einer leeren Liste."""
    try:
        url = 'https://news.google.com/rss/search?' + urllib.parse.urlencode({'q': query, 'hl': 'en-US', 'gl': 'US', 'ceid': 'US:en'})
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 SwingTradingCommandCenter/1.0'})
        with urllib.request.urlopen(request, timeout=8) as response:
            xml_data = response.read()
        root = ET.fromstring(xml_data)
        items = []
        for node in root.findall('./channel/item')[:count]:
            title = _strip_html(node.findtext('title', ''))
            link = node.findtext('link', '') or ''
            pub = node.findtext('pubDate', '') or ''
            source = node.find('source')
            provider = source.text if source is not None and source.text else 'Google News'
            if title:
                items.append(_translate_news_item({'title': title, 'summary': '', 'provider': provider, 'url': link, 'published': _news_timestamp({'published': pub})}))
        return items
    except Exception:
        return []

def fetch_global_news():
    all_items = []
    for category, query in GLOBAL_NEWS_QUERIES.items():
        for item in fetch_google_news_rss(query):
            item = dict(item)
            item['category'] = category
            all_items.append(item)
    dedup, seen = ([], set())
    for item in sorted(all_items, key=lambda x: x.get('published', datetime.min), reverse=True):
        key = re.sub('\\W+', ' ', item.get('title', '').lower()).strip()
        if key and key not in seen:
            seen.add(key)
            dedup.append(item)
    return dedup[:80]

def _article_text(item):
    title = item.get('original_title') or item.get('title', '')
    summary = item.get('original_summary') or item.get('summary', '')
    return f'{title} {summary}'.lower()

def _relevance_score(item, ticker):
    text = _article_text(item)
    aliases = TICKER_ALIASES.get(ticker, [ticker.lower()])
    sector_terms = SECTOR_TERMS.get(ticker, [])
    alias_hits = sum((1 for term in aliases if term.lower() in text))
    sector_hits = sum((1 for term in sector_terms if term.lower() in text))
    category = item.get('category', '')
    macro_bonus = 1 if category in GLOBAL_NEWS_QUERIES else 0
    return alias_hits * 4 + min(sector_hits, 3) * 1.5 + macro_bonus

def rank_global_news_for_ticker(ticker, global_news, limit=10):
    ranked = []
    for item in global_news:
        relevance = _relevance_score(item, ticker)
        if relevance <= 0:
            continue
        age_hours = max(0.0, (datetime.now() - item.get('published', datetime.now())).total_seconds() / 3600)
        recency = max(0.15, 1.0 / (1.0 + age_hours / 24.0))
        ranked.append((relevance * recency, item))
    ranked.sort(key=lambda x: x[0], reverse=True)
    return [dict(item, relevance=round(score, 2)) for score, item in ranked[:limit]]

def fetch_sector_news_for_ticker(ticker):
    terms = SECTOR_TERMS.get(ticker, [])[:4]
    if not terms:
        return []
    query = ' OR '.join((f'"{term}"' for term in terms))
    items = fetch_google_news_rss(query, count=NEWS_MAX_ARTICLES_PER_SOURCE)
    for item in items:
        item['category'] = 'sector'
    return items

def _source_quality(provider):
    name = str(provider or '').lower()
    for source, weight in NEWS_SOURCE_WEIGHTS.items():
        if source in name:
            return weight
    return 0.98

def _news_sentiment(item):
    text = _article_text(item)
    positive_hits = sum((1 for term in POSITIVE_NEWS_TERMS if term in text))
    negative_hits = sum((1 for term in NEGATIVE_NEWS_TERMS if term in text))
    raw = np.clip(positive_hits - negative_hits, -3, 3) / 3.0
    impact_hits = sum((1 for term in HIGH_IMPACT_TERMS if term in text))
    if impact_hits and raw != 0:
        raw = float(np.clip(raw * (1.0 + min(impact_hits, 3) * 0.12), -1, 1))
    return float(raw)

def _news_severity(item):
    text = _article_text(item)
    hits = sum((1 for term in NEWS_SEVERITY_TERMS if term in text))
    return float(min(1.45, 0.85 + hits * 0.12))

def _news_recency(item):
    age_hours = max(0.0, (datetime.now() - item.get('published', datetime.now())).total_seconds() / 3600)
    return float(max(0.15, 1.0 / (1.0 + age_hours / 24.0)))

def _matched_themes(item):
    text = _article_text(item)
    return [theme for theme, terms in THEME_KEYWORDS.items() if any((term in text for term in terms))]

def _sector_keys_for_ticker(ticker):
    text = ' '.join(TICKER_ALIASES.get(ticker, []) + SECTOR_TERMS.get(ticker, [])).lower()
    keys = set()
    if any((x in text for x in ['semiconductor', 'chip', 'gpu', 'dram', 'nand', 'applied materials', 'qualcomm'])):
        keys.add('semiconductors')
        keys.add('technology')
    if any((x in text for x in ['bank', 'jpmorgan', 'goldman', 'morgan stanley', 'wells fargo', 'citi'])):
        keys.add('banks')
        keys.add('financials')
    if any((x in text for x in ['auto', 'tesla', 'bmw', 'mercedes', 'volkswagen'])):
        keys.add('autos')
    if any((x in text for x in ['exxon', 'chevron', 'oil', 'energy'])):
        keys.add('energy')
    if any((x in text for x in ['defense', 'lockheed', 'northrop', 'raytheon'])):
        keys.add('defense')
    if any((x in text for x in ['airline', 'delta', 'united airlines', 'american airlines'])):
        keys.add('airlines')
    if not keys and any((x in text for x in ['software', 'cloud', 'apple', 'microsoft', 'google', 'amazon', 'meta'])):
        keys.add('technology')
    return keys

def _article_impact_for_ticker(item, ticker):
    text = _article_text(item)
    sentiment = _news_sentiment(item)
    themes = _matched_themes(item)
    sector_keys = _sector_keys_for_ticker(ticker)
    category = item.get('category', '')
    relevance = float(item.get('relevance', 1.0))
    if category == 'company':
        relevance = max(relevance, 1.0)
    elif category == 'sector':
        relevance = max(relevance, 0.75)
    relevance_factor = float(np.clip(relevance / 4.0, 0.35, 1.0))
    theme_effects = []
    for theme in themes:
        effects = GLOBAL_THEME_SECTOR_EFFECTS.get(theme, {})
        for sector in sector_keys:
            if sector in effects and effects[sector] != 0:
                multiplier = TICKER_IMPACT_THEMES.get(ticker, {}).get(sector, 1.0)
                theme_effects.append((theme, effects[sector] * multiplier))
        if category == theme:
            theme_effects.append((theme, 0.35))
    thematic_bias = float(np.mean([v for _, v in theme_effects])) if theme_effects else 0.0
    if category in ('company', 'sector'):
        signed = sentiment
    else:
        signed = sentiment * (0.65 + 0.35 * abs(thematic_bias))
        if thematic_bias != 0 and sentiment == 0:
            signed = float(np.clip(thematic_bias, -1, 1))
        elif thematic_bias != 0:
            signed = float(np.clip(0.65 * sentiment + 0.35 * np.sign(sentiment) * np.clip(thematic_bias, -1, 1), -1, 1))
    impact = signed * relevance_factor * _news_recency(item) * _news_severity(item) * _source_quality(item.get('provider'))
    return (float(np.clip(impact, -1.5, 1.5)), {'sentiment': round(sentiment, 2), 'themes': themes, 'relevance': round(relevance_factor, 2), 'severity': round(_news_severity(item), 2), 'recency': round(_news_recency(item), 2), 'source_quality': round(_source_quality(item.get('provider')), 2)})

def _impact_bucket(news_items, ticker, direction, max_points):
    if not news_items:
        return (max_points * 0.5, [])
    events = []
    for item in news_items:
        impact, meta = _article_impact_for_ticker(item, ticker)
        directional = impact if direction == 'LONG' else -impact
        events.append({'title': item.get('title', ''), 'provider': item.get('provider', ''), 'url': item.get('url', ''), 'published': item.get('published'), 'impact': directional, 'raw_impact': impact, **meta})
    events.sort(key=lambda x: abs(x['impact']), reverse=True)
    strongest = events[:5]
    net = float(np.clip(sum((e['impact'] for e in strongest)) / max(1.0, len(strongest) * 1.05), -1, 1))
    points = float(np.clip(max_points * (0.5 + 0.5 * net), 0, max_points))
    return (points, events)

def build_news_intelligence(ticker, company_news, global_news):
    sector_news = fetch_sector_news_for_ticker(ticker)
    global_relevant = rank_global_news_for_ticker(ticker, global_news, limit=10)
    return {'company': company_news or [], 'sector': sector_news, 'global': global_relevant}

def score_news_intelligence(news_intel, direction, ticker=''):
    company_points, company_events = _impact_bucket(news_intel.get('company', []), ticker, direction, COMPANY_NEWS_POINTS)
    sector_points, sector_events = _impact_bucket(news_intel.get('sector', []), ticker, direction, SECTOR_NEWS_POINTS)
    global_points, global_events = _impact_bucket(news_intel.get('global', []), ticker, direction, GLOBAL_NEWS_POINTS)
    total = int(np.clip(round(company_points + sector_points + global_points), 0, NEWS_SCORE_MAX))

    def label(points, max_points):
        if points >= max_points * 0.75:
            return 'klar unterstützend'
        if points >= max_points * 0.55:
            return 'leicht unterstützend'
        if points >= max_points * 0.4:
            return 'neutral/gemischt'
        return 'gegen die Richtung'
    events = sorted(company_events + sector_events + global_events, key=lambda x: abs(x['impact']), reverse=True)
    return {'total': total, 'company': int(round(company_points)), 'sector': int(round(sector_points)), 'global': int(round(global_points)), 'company_label': label(company_points, COMPANY_NEWS_POINTS), 'sector_label': label(sector_points, SECTOR_NEWS_POINTS), 'global_label': label(global_points, GLOBAL_NEWS_POINTS), 'events': events[:10], 'net_impact': round(sum((e['impact'] for e in events[:5])), 2)}

def news_headlines_text(news_items, limit=3):
    if not news_items:
        return 'Keine News'
    return ' | '.join([item['title'] for item in news_items if item.get('title')][:limit])

def _candle_parts(row):
    o = safe_float(row.get('Open'))
    h = safe_float(row.get('High'))
    l = safe_float(row.get('Low'))
    c = safe_float(row.get('Close'))
    if any((np.isnan(x) for x in (o, h, l, c))):
        return None
    body = abs(c - o)
    rng = max(h - l, 1e-12)
    upper = h - max(o, c)
    lower = min(o, c) - l
    bull = c > o
    bear = c < o
    return {'o': o, 'h': h, 'l': l, 'c': c, 'body': body, 'range': rng, 'upper': upper, 'lower': lower, 'bull': bull, 'bear': bear}

def _body_ratio(x):
    return x['body'] / x['range'] if x else 0.0

def _near(a, b, tolerance):
    return abs(a - b) <= tolerance

def detect_candlestick_patterns(df, lookback=12):
    """Erkennt verbreitete klassische Candlestick-Formationen und bewertet ihren Kontext.
    Mehrere Formationen können gleichzeitig erkannt werden. Die Bewertung ist richtungsbezogen:
    bullisch = LONG-Unterstützung, bärisch = SHORT-Unterstützung.
    """
    if df is None or df.empty or len(df) < 3:
        return []
    d = df.dropna(subset=['Open', 'High', 'Low', 'Close']).copy()
    rows = []
    start = max(1, len(d) - lookback)
    for i in range(start, len(d)):
        x = _candle_parts(d.iloc[i])
        p = _candle_parts(d.iloc[i - 1])
        p2 = _candle_parts(d.iloc[i - 2]) if i >= 2 else None
        if not x or not p:
            continue
        avg_body = float(d['Close'].iloc[max(0, i - 10):i].sub(d['Open'].iloc[max(0, i - 10):i]).abs().mean() or x['body'])
        small = x['body'] <= x['range'] * 0.12
        long_body = x['body'] >= max(avg_body * 1.35, x['range'] * 0.55)
        lower_long = x['lower'] >= max(x['body'] * 2.0, x['range'] * 0.55)
        upper_long = x['upper'] >= max(x['body'] * 2.0, x['range'] * 0.55)
        trend_up = False
        trend_down = False
        if i >= 5:
            closes = d['Close'].iloc[i - 5:i].values
            trend_up = closes[-1] > closes[0] and closes[-1] > d['Close'].iloc[i - 3]
            trend_down = closes[-1] < closes[0] and closes[-1] < d['Close'].iloc[i - 3]
        tol = x['range'] * 0.12
        found = []

        def add(name, bias, strength, explanation):
            found.append({'pattern': name, 'bias': bias, 'strength': int(strength), 'explanation': explanation, 'time': d.index[i]})
        if small and x['upper'] > x['body'] * 1.5 and (x['lower'] > x['body'] * 1.5):
            add('Doji / Neutral Doji', 'NEUTRAL', 2, 'Unentschlossenheit; Richtung braucht Bestätigung.')
        if small and x['lower'] <= x['range'] * 0.08 and (x['upper'] >= x['range'] * 0.6):
            add('Gravestone Doji', 'BEARISH', 4, 'Starke Zurückweisung höherer Kurse.')
        if small and x['upper'] <= x['range'] * 0.08 and (x['lower'] >= x['range'] * 0.6):
            add('Dragonfly Doji', 'BULLISH', 4, 'Starke Zurückweisung tieferer Kurse.')
        if lower_long and x['upper'] <= x['body'] * 0.8:
            if trend_down:
                add('Hammer', 'BULLISH', 5, 'Bullische Rejection nach Abwärtsbewegung.')
            elif trend_up:
                add('Hanging Man', 'BEARISH', 4, 'Warnsignal nach Aufwärtsbewegung; Bestätigung nötig.')
            else:
                add('Hammer-ähnliche Rejection', 'BULLISH', 3, 'Langer unterer Docht; Kontext nicht eindeutig.')
        if upper_long and x['lower'] <= x['body'] * 0.8:
            if trend_down:
                add('Inverted Hammer', 'BULLISH', 4, 'Mögliche bullische Umkehr nach Abwärtsbewegung.')
            elif trend_up:
                add('Shooting Star', 'BEARISH', 5, 'Bärische Rejection am Hoch.')
            else:
                add('Shooting-Star-ähnliche Rejection', 'BEARISH', 3, 'Langer oberer Docht; Kontext nicht eindeutig.')
        if long_body and x['upper'] <= x['range'] * 0.08 and (x['lower'] <= x['range'] * 0.08):
            add('Bullish Marubozu', 'BULLISH', 4, 'Starker Kaufdruck ohne relevante Dochte.') if x['bull'] else add('Bearish Marubozu', 'BEARISH', 4, 'Starker Verkaufsdruck ohne relevante Dochte.')
        if _body_ratio(x) < 0.35 and (not small) and (x['upper'] > x['body']) and (x['lower'] > x['body']):
            add('Spinning Top', 'NEUTRAL', 2, 'Unentschlossenheit und nachlassender Impuls.')
        if p['bear'] and x['bull'] and (x['o'] <= p['c']) and (x['c'] >= p['o']) and (x['body'] >= p['body'] * 0.9):
            add('Bullish Engulfing', 'BULLISH', 6, 'Aktuelle bullische Kerze umfasst den Vortageskörper.')
        if p['bull'] and x['bear'] and (x['o'] >= p['c']) and (x['c'] <= p['o']) and (x['body'] >= p['body'] * 0.9):
            add('Bearish Engulfing', 'BEARISH', 6, 'Aktuelle bärische Kerze umfasst den Vortageskörper.')
        if p['bear'] and x['bull'] and (x['body'] < p['body'] * 0.65) and (x['o'] >= p['c']) and (x['c'] <= p['o']):
            add('Bullish Harami', 'BULLISH', 4, 'Kleiner bullischer Körper innerhalb des Vortageskörpers.')
        if p['bull'] and x['bear'] and (x['body'] < p['body'] * 0.65) and (x['o'] <= p['c']) and (x['c'] >= p['o']):
            add('Bearish Harami', 'BEARISH', 4, 'Kleiner bärischer Körper innerhalb des Vortageskörpers.')
        if p['bear'] and x['bull'] and (x['o'] < p['l']) and (x['c'] > (p['o'] + p['c']) / 2) and (x['c'] < p['o']):
            add('Piercing Line', 'BULLISH', 5, 'Bullische Erholung über die Hälfte der Vortageskerze.')
        if p['bull'] and x['bear'] and (x['o'] > p['h']) and (x['c'] < (p['o'] + p['c']) / 2) and (x['c'] > p['o']):
            add('Dark Cloud Cover', 'BEARISH', 5, 'Bärische Rückkehr unter die Mitte der Vortageskerze.')
        if _near(x['l'], p['l'], tol) and x['bull'] and p['bear']:
            add('Tweezer Bottom', 'BULLISH', 4, 'Ähnliche Tiefs mit bullischer Reaktion.')
        if _near(x['h'], p['h'], tol) and x['bear'] and p['bull']:
            add('Tweezer Top', 'BEARISH', 4, 'Ähnliche Hochs mit bärischer Reaktion.')
        if x['h'] < p['h'] and x['l'] > p['l']:
            add('Inside Bar', 'NEUTRAL', 3, 'Kompression; Ausbruch aus der Range ist der Trigger.')
        if x['h'] > p['h'] and x['l'] < p['l']:
            add('Outside Bar', 'BULLISH' if x['bull'] else 'BEARISH', 4, 'Erweiterung der Handelsspanne; Schlussrichtung zählt.')
        if p2:
            p2_mid = (p2['o'] + p2['c']) / 2
            if p2['bear'] and _body_ratio(p) < 0.35 and x['bull'] and (x['c'] > p2_mid):
                add('Morning Star', 'BULLISH', 7, 'Dreikerzen-Umkehr mit bullischer Bestätigung.')
            if p2['bull'] and _body_ratio(p) < 0.35 and x['bear'] and (x['c'] < p2_mid):
                add('Evening Star', 'BEARISH', 7, 'Dreikerzen-Umkehr mit bärischer Bestätigung.')
            if all((z['bull'] for z in (p2, p, x))) and p2['c'] < p['c'] < x['c'] and (p['o'] >= p2['o']) and (x['o'] >= p['o']):
                add('Three White Soldiers', 'BULLISH', 7, 'Drei aufeinanderfolgende starke bullische Kerzen.')
            if all((z['bear'] for z in (p2, p, x))) and p2['c'] > p['c'] > x['c'] and (p['o'] <= p2['o']) and (x['o'] <= p['o']):
                add('Three Black Crows', 'BEARISH', 7, 'Drei aufeinanderfolgende starke bärische Kerzen.')
        for item in found:
            if item['pattern'] in {'Hammer', 'Inverted Hammer', 'Morning Star', 'Bullish Engulfing', 'Piercing Line', 'Tweezer Bottom'} and trend_down:
                item['strength'] = min(10, item['strength'] + 1)
            if item['pattern'] in {'Shooting Star', 'Hanging Man', 'Evening Star', 'Bearish Engulfing', 'Dark Cloud Cover', 'Tweezer Top'} and trend_up:
                item['strength'] = min(10, item['strength'] + 1)
            rows.append(item)
    rows.sort(key=lambda x: (x['strength'], x['time']), reverse=True)
    return rows

def summarize_candlestick_patterns(df, direction):
    patterns = detect_candlestick_patterns(df, lookback=12)
    aligned = [p for p in patterns if p['bias'] == direction]
    opposed = [p for p in patterns if p['bias'] not in (direction, 'NEUTRAL')]
    aligned_strength = sum((p['strength'] for p in aligned[:4]))
    opposed_strength = sum((p['strength'] for p in opposed[:3]))
    score = int(np.clip(50 + aligned_strength * 4 - opposed_strength * 4, 0, 100))
    return {'patterns': patterns, 'aligned': aligned, 'opposed': opposed, 'score': score}
FUNDAMENTAL_CACHE_TTL = 1800

def _metric_num(value):
    try:
        value = float(value)
        return value if np.isfinite(value) else np.nan
    except Exception:
        return np.nan

def fetch_company_fundamentals(ticker):
    """Lädt Unternehmenskennzahlen separat vom Trading-Setup."""
    try:
        info = yf.Ticker(ticker).get_info()
        fields = ['marketCap', 'enterpriseValue', 'trailingPE', 'forwardPE', 'pegRatio', 'priceToSalesTrailing12Months', 'priceToBook', 'enterpriseToEbitda', 'profitMargins', 'operatingMargins', 'grossMargins', 'returnOnEquity', 'returnOnAssets', 'debtToEquity', 'currentRatio', 'quickRatio', 'revenueGrowth', 'earningsGrowth', 'earningsQuarterlyGrowth', 'freeCashflow', 'operatingCashflow', 'totalRevenue', 'totalCash', 'totalDebt', 'dividendYield', 'dividendRate', 'beta', 'recommendationKey', 'targetMeanPrice', 'bookValue', 'sharesOutstanding', 'sector', 'industry', 'shortName', 'currency', 'currentPrice', 'regularMarketPrice']
        return {k: info.get(k) for k in fields}
    except Exception:
        return {}

def _fmt_metric(v, pct=False, multiple=False):
    v = _metric_num(v)
    if np.isnan(v):
        return 'n/a'
    if pct:
        return f'{v * 100:.1f}%'
    if multiple:
        return f'{v:.1f}x'
    if abs(v) >= 1000000000.0:
        return f'{v / 1000000000.0:.2f} Mrd.'
    if abs(v) >= 1000000.0:
        return f'{v / 1000000.0:.2f} Mio.'
    return f'{v:,.2f}'

def score_fundamentals(f):
    """Unabhängiger 0-100 Fundamental-Score; nicht Teil des Trading-Scores."""
    if not f:
        return {'score': None, 'grade': 'Keine Daten', 'reasons': []}
    points = 50.0
    reasons = []

    def judge(name, value, good, bad, weight):
        nonlocal points
        v = _metric_num(value)
        if np.isnan(v):
            return
        if good(v):
            points += weight
            reasons.append(f'✓ {name}')
        elif bad(v):
            points -= weight
            reasons.append(f'⚠ {name}')
    judge('KGV', f.get('trailingPE'), lambda v: 0 < v <= 25, lambda v: v > 45 or v <= 0, 6)
    judge('Forward-KGV', f.get('forwardPE'), lambda v: 0 < v <= 22, lambda v: v > 40 or v <= 0, 6)
    judge('PEG', f.get('pegRatio'), lambda v: 0 < v <= 1.5, lambda v: v > 2.5 or v <= 0, 5)
    judge('KUV', f.get('priceToSalesTrailing12Months'), lambda v: 0 < v <= 5, lambda v: v > 10 or v <= 0, 4)
    judge('KBV', f.get('priceToBook'), lambda v: 0 < v <= 4, lambda v: v > 8 or v <= 0, 4)
    judge('ROE', f.get('returnOnEquity'), lambda v: v >= 0.15, lambda v: v < 0, 6)
    judge('ROA', f.get('returnOnAssets'), lambda v: v >= 0.05, lambda v: v < 0, 4)
    judge('Umsatzwachstum', f.get('revenueGrowth'), lambda v: v >= 0.1, lambda v: v < 0, 5)
    judge('Gewinnwachstum', f.get('earningsGrowth'), lambda v: v >= 0.1, lambda v: v < 0, 6)
    judge('Free-Cashflow', f.get('freeCashflow'), lambda v: v > 0, lambda v: v < 0, 5)
    judge('Verschuldung D/E', f.get('debtToEquity'), lambda v: v < 100, lambda v: v > 200, 5)
    judge('Current Ratio', f.get('currentRatio'), lambda v: v >= 1.2, lambda v: v < 0.8, 4)
    judge('Nettomarge', f.get('profitMargins'), lambda v: v >= 0.1, lambda v: v < 0, 5)
    score = int(np.clip(round(points), 0, 100))
    grade = 'Sehr stark' if score >= 80 else 'Stark' if score >= 65 else 'Neutral' if score >= 45 else 'Schwach'
    return {'score': score, 'grade': grade, 'reasons': reasons}

def build_fundamental_snapshot(ticker):
    f = fetch_company_fundamentals(ticker)
    return {'metrics': f, 'assessment': score_fundamentals(f)}

def _candle_parts(row):
    o = safe_float(row.get('Open'))
    h = safe_float(row.get('High'))
    l = safe_float(row.get('Low'))
    c = safe_float(row.get('Close'))
    if any((np.isnan(x) for x in (o, h, l, c))):
        return None
    body = abs(c - o)
    rng = max(h - l, 1e-12)
    upper = h - max(o, c)
    lower = min(o, c) - l
    bull = c > o
    bear = c < o
    return {'o': o, 'h': h, 'l': l, 'c': c, 'body': body, 'range': rng, 'upper': upper, 'lower': lower, 'bull': bull, 'bear': bear}

def _body_ratio(x):
    return x['body'] / x['range'] if x else 0.0

def _near(a, b, tolerance):
    return abs(a - b) <= tolerance

def detect_candlestick_patterns(df, lookback=12):
    """Erkennt verbreitete klassische Candlestick-Formationen und bewertet ihren Kontext.
    Mehrere Formationen können gleichzeitig erkannt werden. Die Bewertung ist richtungsbezogen:
    bullisch = LONG-Unterstützung, bärisch = SHORT-Unterstützung.
    """
    if df is None or df.empty or len(df) < 3:
        return []
    d = df.dropna(subset=['Open', 'High', 'Low', 'Close']).copy()
    rows = []
    start = max(1, len(d) - lookback)
    for i in range(start, len(d)):
        x = _candle_parts(d.iloc[i])
        p = _candle_parts(d.iloc[i - 1])
        p2 = _candle_parts(d.iloc[i - 2]) if i >= 2 else None
        if not x or not p:
            continue
        avg_body = float(d['Close'].iloc[max(0, i - 10):i].sub(d['Open'].iloc[max(0, i - 10):i]).abs().mean() or x['body'])
        small = x['body'] <= x['range'] * 0.12
        long_body = x['body'] >= max(avg_body * 1.35, x['range'] * 0.55)
        lower_long = x['lower'] >= max(x['body'] * 2.0, x['range'] * 0.55)
        upper_long = x['upper'] >= max(x['body'] * 2.0, x['range'] * 0.55)
        trend_up = False
        trend_down = False
        if i >= 5:
            closes = d['Close'].iloc[i - 5:i].values
            trend_up = closes[-1] > closes[0] and closes[-1] > d['Close'].iloc[i - 3]
            trend_down = closes[-1] < closes[0] and closes[-1] < d['Close'].iloc[i - 3]
        tol = x['range'] * 0.12
        found = []

        def add(name, bias, strength, explanation):
            found.append({'pattern': name, 'bias': bias, 'strength': int(strength), 'explanation': explanation, 'time': d.index[i]})
        if small and x['upper'] > x['body'] * 1.5 and (x['lower'] > x['body'] * 1.5):
            add('Doji / Neutral Doji', 'NEUTRAL', 2, 'Unentschlossenheit; Richtung braucht Bestätigung.')
        if small and x['lower'] <= x['range'] * 0.08 and (x['upper'] >= x['range'] * 0.6):
            add('Gravestone Doji', 'BEARISH', 4, 'Starke Zurückweisung höherer Kurse.')
        if small and x['upper'] <= x['range'] * 0.08 and (x['lower'] >= x['range'] * 0.6):
            add('Dragonfly Doji', 'BULLISH', 4, 'Starke Zurückweisung tieferer Kurse.')
        if lower_long and x['upper'] <= x['body'] * 0.8:
            if trend_down:
                add('Hammer', 'BULLISH', 5, 'Bullische Rejection nach Abwärtsbewegung.')
            elif trend_up:
                add('Hanging Man', 'BEARISH', 4, 'Warnsignal nach Aufwärtsbewegung; Bestätigung nötig.')
            else:
                add('Hammer-ähnliche Rejection', 'BULLISH', 3, 'Langer unterer Docht; Kontext nicht eindeutig.')
        if upper_long and x['lower'] <= x['body'] * 0.8:
            if trend_down:
                add('Inverted Hammer', 'BULLISH', 4, 'Mögliche bullische Umkehr nach Abwärtsbewegung.')
            elif trend_up:
                add('Shooting Star', 'BEARISH', 5, 'Bärische Rejection am Hoch.')
            else:
                add('Shooting-Star-ähnliche Rejection', 'BEARISH', 3, 'Langer oberer Docht; Kontext nicht eindeutig.')
        if long_body and x['upper'] <= x['range'] * 0.08 and (x['lower'] <= x['range'] * 0.08):
            add('Bullish Marubozu', 'BULLISH', 4, 'Starker Kaufdruck ohne relevante Dochte.') if x['bull'] else add('Bearish Marubozu', 'BEARISH', 4, 'Starker Verkaufsdruck ohne relevante Dochte.')
        if _body_ratio(x) < 0.35 and (not small) and (x['upper'] > x['body']) and (x['lower'] > x['body']):
            add('Spinning Top', 'NEUTRAL', 2, 'Unentschlossenheit und nachlassender Impuls.')
        if p['bear'] and x['bull'] and (x['o'] <= p['c']) and (x['c'] >= p['o']) and (x['body'] >= p['body'] * 0.9):
            add('Bullish Engulfing', 'BULLISH', 6, 'Aktuelle bullische Kerze umfasst den Vortageskörper.')
        if p['bull'] and x['bear'] and (x['o'] >= p['c']) and (x['c'] <= p['o']) and (x['body'] >= p['body'] * 0.9):
            add('Bearish Engulfing', 'BEARISH', 6, 'Aktuelle bärische Kerze umfasst den Vortageskörper.')
        if p['bear'] and x['bull'] and (x['body'] < p['body'] * 0.65) and (x['o'] >= p['c']) and (x['c'] <= p['o']):
            add('Bullish Harami', 'BULLISH', 4, 'Kleiner bullischer Körper innerhalb des Vortageskörpers.')
        if p['bull'] and x['bear'] and (x['body'] < p['body'] * 0.65) and (x['o'] <= p['c']) and (x['c'] >= p['o']):
            add('Bearish Harami', 'BEARISH', 4, 'Kleiner bärischer Körper innerhalb des Vortageskörpers.')
        if p['bear'] and x['bull'] and (x['o'] < p['l']) and (x['c'] > (p['o'] + p['c']) / 2) and (x['c'] < p['o']):
            add('Piercing Line', 'BULLISH', 5, 'Bullische Erholung über die Hälfte der Vortageskerze.')
        if p['bull'] and x['bear'] and (x['o'] > p['h']) and (x['c'] < (p['o'] + p['c']) / 2) and (x['c'] > p['o']):
            add('Dark Cloud Cover', 'BEARISH', 5, 'Bärische Rückkehr unter die Mitte der Vortageskerze.')
        if _near(x['l'], p['l'], tol) and x['bull'] and p['bear']:
            add('Tweezer Bottom', 'BULLISH', 4, 'Ähnliche Tiefs mit bullischer Reaktion.')
        if _near(x['h'], p['h'], tol) and x['bear'] and p['bull']:
            add('Tweezer Top', 'BEARISH', 4, 'Ähnliche Hochs mit bärischer Reaktion.')
        if x['h'] < p['h'] and x['l'] > p['l']:
            add('Inside Bar', 'NEUTRAL', 3, 'Kompression; Ausbruch aus der Range ist der Trigger.')
        if x['h'] > p['h'] and x['l'] < p['l']:
            add('Outside Bar', 'BULLISH' if x['bull'] else 'BEARISH', 4, 'Erweiterung der Handelsspanne; Schlussrichtung zählt.')
        if p2:
            p2_mid = (p2['o'] + p2['c']) / 2
            if p2['bear'] and _body_ratio(p) < 0.35 and x['bull'] and (x['c'] > p2_mid):
                add('Morning Star', 'BULLISH', 7, 'Dreikerzen-Umkehr mit bullischer Bestätigung.')
            if p2['bull'] and _body_ratio(p) < 0.35 and x['bear'] and (x['c'] < p2_mid):
                add('Evening Star', 'BEARISH', 7, 'Dreikerzen-Umkehr mit bärischer Bestätigung.')
            if all((z['bull'] for z in (p2, p, x))) and p2['c'] < p['c'] < x['c'] and (p['o'] >= p2['o']) and (x['o'] >= p['o']):
                add('Three White Soldiers', 'BULLISH', 7, 'Drei aufeinanderfolgende starke bullische Kerzen.')
            if all((z['bear'] for z in (p2, p, x))) and p2['c'] > p['c'] > x['c'] and (p['o'] <= p2['o']) and (x['o'] <= p['o']):
                add('Three Black Crows', 'BEARISH', 7, 'Drei aufeinanderfolgende starke bärische Kerzen.')
        for item in found:
            if item['pattern'] in {'Hammer', 'Inverted Hammer', 'Morning Star', 'Bullish Engulfing', 'Piercing Line', 'Tweezer Bottom'} and trend_down:
                item['strength'] = min(10, item['strength'] + 1)
            if item['pattern'] in {'Shooting Star', 'Hanging Man', 'Evening Star', 'Bearish Engulfing', 'Dark Cloud Cover', 'Tweezer Top'} and trend_up:
                item['strength'] = min(10, item['strength'] + 1)
            rows.append(item)
    rows.sort(key=lambda x: (x['strength'], x['time']), reverse=True)
    return rows

def summarize_candlestick_patterns(df, direction):
    patterns = detect_candlestick_patterns(df, lookback=12)
    aligned = [p for p in patterns if p['bias'] == direction]
    opposed = [p for p in patterns if p['bias'] not in (direction, 'NEUTRAL')]
    aligned_strength = sum((p['strength'] for p in aligned[:4]))
    opposed_strength = sum((p['strength'] for p in opposed[:3]))
    score = int(np.clip(50 + aligned_strength * 4 - opposed_strength * 4, 0, 100))
    return {'patterns': patterns, 'aligned': aligned, 'opposed': opposed, 'score': score}
FUNDAMENTAL_CACHE_TTL = 1800

def _metric_num(value):
    try:
        value = float(value)
        return value if np.isfinite(value) else np.nan
    except Exception:
        return np.nan

def _benchmark_for_ticker(ticker):
    """Wählt einen sinnvollen Referenzindex anhand des Ticker-Suffixes."""
    t = str(ticker or '').upper()
    suffix_map = {'.DE': '^GDAXI', '.F': '^GDAXI', '.BE': '^BFX', '.PA': '^FCHI', '.MI': 'FTSEMIB.MI', '.AS': '^AEX', '.L': '^FTSE', '.SW': '^SSMI', '.TO': '^GSPTSE', '.HK': '^HSI', '.T': '^N225', '.SI': '^STI'}
    for suffix, benchmark in suffix_map.items():
        if t.endswith(suffix):
            return benchmark
    return DEFAULT_BENCHMARK

def _date_like_to_datetime(value):
    try:
        ts = pd.Timestamp(value)
        if ts.tzinfo is not None:
            ts = ts.tz_localize(None)
        return ts.to_pydatetime()
    except Exception:
        return None

def fetch_earnings_intelligence(ticker):
    """Analystenschätzungen, Earnings Surprise, Revisionen und nächster Termin."""
    empty = {'latest_surprise_pct': np.nan, 'avg_surprise_pct': np.nan, 'eps_up_30d': 0, 'eps_down_30d': 0, 'eps_revision_net': 0, 'eps_trend_current': np.nan, 'eps_trend_30d': np.nan, 'eps_trend_change': np.nan, 'analyst_count': np.nan, 'eps_estimate_next': np.nan, 'eps_growth_next': np.nan, 'target_mean': np.nan, 'target_upside_pct': np.nan, 'next_earnings': None, 'days_to_earnings': np.nan, 'event_risk_score': 100, 'earnings_score': 50, 'status': 'Keine Earnings-Daten'}
    try:
        t = yf.Ticker(ticker)
        info = t.get_info() or {}
        hist = t.get_earnings_history(as_dict=False)
        revisions = t.get_eps_revisions(as_dict=False)
        trend = t.get_eps_trend(as_dict=False)
        estimates = t.get_earnings_estimate(as_dict=False)
        targets = t.get_analyst_price_targets()
        dates = t.get_earnings_dates(limit=8)
        out = dict(empty)
        surprises = []
        if hist is not None and (not hist.empty) and ('surprisePercent' in hist.columns):
            surprises = pd.to_numeric(hist['surprisePercent'], errors='coerce').dropna().tail(4).tolist()
            if surprises:
                out['latest_surprise_pct'] = float(surprises[-1])
                out['avg_surprise_pct'] = float(np.mean(surprises))
        if revisions is not None and (not revisions.empty):
            row = revisions.iloc[0]
            for key in ('upLast30days', 'downLast30days', 'upLast7days', 'downLast7days'):
                if key in revisions.columns:
                    out['eps_' + ('up_30d' if key == 'upLast30days' else 'down_30d' if key == 'downLast30days' else key.replace('Last', '_last').replace('days', 'd'))] = int(_metric_num(row.get(key)) if not np.isnan(_metric_num(row.get(key))) else 0)
            up = _metric_num(row.get('upLast30days'))
            down = _metric_num(row.get('downLast30days'))
            out['eps_up_30d'] = int(0 if np.isnan(up) else up)
            out['eps_down_30d'] = int(0 if np.isnan(down) else down)
            out['eps_revision_net'] = out['eps_up_30d'] - out['eps_down_30d']
        if trend is not None and (not trend.empty):
            row = trend.iloc[0]
            cur = _metric_num(row.get('current'))
            old = _metric_num(row.get('30daysAgo'))
            out['eps_trend_current'] = cur
            out['eps_trend_30d'] = old
            if not np.isnan(cur) and (not np.isnan(old)):
                out['eps_trend_change'] = float(cur - old)
        if estimates is not None and (not estimates.empty):
            row = estimates.iloc[0]
            out['analyst_count'] = _metric_num(row.get('numberOfAnalysts'))
            out['eps_estimate_next'] = _metric_num(row.get('avg'))
            out['eps_growth_next'] = _metric_num(row.get('growth'))
        if isinstance(targets, dict):
            out['target_mean'] = _metric_num(targets.get('mean'))
        current = _metric_num(info.get('currentPrice'))
        if np.isnan(current):
            current = _metric_num(info.get('regularMarketPrice'))
        if not np.isnan(current) and (not np.isnan(out['target_mean'])) and (current > 0):
            out['target_upside_pct'] = (out['target_mean'] / current - 1) * 100
        future_dates = []
        if dates is not None and (not dates.empty):
            for idx in dates.index:
                dt = _date_like_to_datetime(idx)
                if dt and dt.date() >= datetime.now().date():
                    future_dates.append(dt)
        if future_dates:
            nxt = min(future_dates)
            out['next_earnings'] = nxt
            out['days_to_earnings'] = max(0, (nxt.date() - datetime.now().date()).days)
        dte = out['days_to_earnings']
        if np.isnan(dte):
            out['event_risk_score'] = 100
            out['status'] = 'Kein naher Earnings-Termin gefunden'
        elif dte <= EARNINGS_RISK_DAYS:
            out['event_risk_score'] = 15
            out['status'] = 'HOHES Earnings-Risiko'
        elif dte <= 7:
            out['event_risk_score'] = 40
            out['status'] = 'Erhöhtes Earnings-Risiko'
        elif dte <= 21:
            out['event_risk_score'] = 70
            out['status'] = 'Earnings in Sicht'
        else:
            out['event_risk_score'] = 100
            out['status'] = 'Kein kurzfristiges Earnings-Risiko'
        score = 50.0
        avg_surprise = _metric_num(out['avg_surprise_pct'])
        if not np.isnan(avg_surprise):
            score += float(np.clip(avg_surprise * 2.0, -20, 20))
        score += float(np.clip(out['eps_revision_net'] * 3.0, -15, 15))
        trend_change = _metric_num(out['eps_trend_change'])
        if not np.isnan(trend_change) and trend_change != 0:
            score += 10 if trend_change > 0 else -10
        target_upside = _metric_num(out['target_upside_pct'])
        if not np.isnan(target_upside):
            score += float(np.clip(target_upside * 0.2, -10, 10))
        out['earnings_score'] = int(np.clip(round(score), 0, 100))
        return out
    except Exception:
        return empty

def fetch_relative_strength(ticker, benchmark=None):
    """20/60-Tage Relative Strength gegenüber einem Referenzindex."""
    benchmark = benchmark or _benchmark_for_ticker(ticker)
    empty = {'benchmark': benchmark, 'return_20': np.nan, 'return_60': np.nan, 'benchmark_20': np.nan, 'benchmark_60': np.nan, 'excess_20': np.nan, 'excess_60': np.nan, 'score': 50}
    try:

        def hist(symbol):
            h = yf.Ticker(symbol).history(period='8mo', interval='1d', auto_adjust=True)
            if h is None or h.empty or 'Close' not in h.columns:
                return None
            return pd.to_numeric(h['Close'], errors='coerce').dropna()
        a, b = (hist(ticker), hist(benchmark))
        if a is None or b is None or len(a) < 65 or (len(b) < 65):
            return empty
        r20 = float(a.iloc[-1] / a.iloc[-21] - 1) * 100
        r60 = float(a.iloc[-1] / a.iloc[-61] - 1) * 100
        br20 = float(b.iloc[-1] / b.iloc[-21] - 1) * 100
        br60 = float(b.iloc[-1] / b.iloc[-61] - 1) * 100
        e20, e60 = (r20 - br20, r60 - br60)
        score = int(np.clip(round(50 + e20 * 2.0 + e60 * 1.0), 0, 100))
        return {'benchmark': benchmark, 'return_20': r20, 'return_60': r60, 'benchmark_20': br20, 'benchmark_60': br60, 'excess_20': e20, 'excess_60': e60, 'score': score}
    except Exception:
        return empty

def build_market_intelligence(ticker, fundamentals=None, benchmark=None):
    earnings = fetch_earnings_intelligence(ticker)
    relative = fetch_relative_strength(ticker, benchmark or _benchmark_for_ticker(ticker))
    score = int(np.clip(round(earnings.get('earnings_score', 50) * 0.45 + relative.get('score', 50) * 0.35 + earnings.get('event_risk_score', 100) * 0.2), 0, 100))
    return {'score': score, 'earnings': earnings, 'relative_strength': relative}

def enrich_peer_comparison(result_df):
    """Vergleicht Bewertung und Wachstum mit den anderen Titeln im aktuellen Scan."""
    if result_df is None or result_df.empty:
        return result_df
    df = result_df.copy()
    df['Peer Score'] = 50.0
    df['Sektor'] = df.get('Sektor', 'Unbekannt')
    for idx, row in df.iterrows():
        sector = row.get('Sektor', 'Unbekannt') or 'Unbekannt'
        peers = df[df['Sektor'].fillna('Unbekannt') == sector]
        if len(peers) < 2:
            peers = df
        score = 50.0
        for col, weight in [('Forward KGV', 15), ('KGV', 10), ('KUV', 5)]:
            v = _metric_num(row.get(col))
            vals = pd.to_numeric(peers[col], errors='coerce') if col in peers else pd.Series(dtype=float)
            vals = vals[np.isfinite(vals) & (vals > 0)]
            if not np.isnan(v) and len(vals) >= 2:
                med = float(vals.median())
                if med > 0:
                    ratio = v / med
                    if ratio <= 0.75:
                        score += weight
                    elif ratio <= 1.0:
                        score += weight * 0.5
                    elif ratio >= 1.5:
                        score -= weight
                    elif ratio >= 1.2:
                        score -= weight * 0.5
        for col, weight in [('Umsatzwachstum', 10), ('Gewinnwachstum', 10), ('Nettomarge', 10)]:
            v = _metric_num(row.get(col))
            vals = pd.to_numeric(peers[col], errors='coerce') if col in peers else pd.Series(dtype=float)
            vals = vals[np.isfinite(vals)]
            if not np.isnan(v) and len(vals) >= 2:
                med = float(vals.median())
                if v > med * 1.1:
                    score += weight
                elif v < med * 0.9:
                    score -= weight
        df.at[idx, 'Peer Score'] = int(np.clip(round(score), 0, 100))
    return df

def analyze_setup(data, news_items=None, news_intelligence=None, ticker='', use_news=True):
    weekly = data.get('Weekly')
    daily = data.get('Daily')
    h4 = data.get('4H')
    h1 = data.get('1H')
    if daily is None:
        return None
    weekly_trend = trend_analysis(weekly)
    daily_trend = trend_analysis(daily)
    structure = market_structure(daily)
    long_score = 0
    short_score = 0
    long_reasons = []
    short_reasons = []
    if weekly_trend['trend'] == 'BULLISH':
        long_score += 15
        long_reasons.append('Weekly-Aufwärtstrend')
    elif weekly_trend['trend'] == 'BEARISH':
        short_score += 15
        short_reasons.append('Weekly-Abwärtstrend')
    if daily_trend['trend'] == 'BULLISH':
        long_score += 15
        long_reasons.append('Daily-Aufwärtstrend')
    elif daily_trend['trend'] == 'BEARISH':
        short_score += 15
        short_reasons.append('Daily-Abwärtstrend')
    if structure['direction'] == 'BULLISH':
        long_score += 15
        long_reasons.append('Bullische Marktstruktur')
    elif structure['direction'] == 'BEARISH':
        short_score += 15
        short_reasons.append('Bärische Marktstruktur')
    if detect_pullback(daily, 'LONG'):
        long_score += 10
        long_reasons.append('Daily Pullback')
    if detect_pullback(daily, 'SHORT'):
        short_score += 10
        short_reasons.append('Daily Pullback')
    if detect_breakout(daily, 'LONG'):
        long_score += 10
        long_reasons.append('Daily Breakout')
    if detect_breakout(daily, 'SHORT'):
        short_score += 10
        short_reasons.append('Daily Breakdown')
    h4_long, _ = momentum_analysis(h4, 'LONG')
    h4_short, _ = momentum_analysis(h4, 'SHORT')
    if h4_long:
        long_score += 10
        long_reasons.append('4H Momentum positiv')
    if h4_short:
        short_score += 10
        short_reasons.append('4H Momentum negativ')
    h1_long, _ = momentum_analysis(h1, 'LONG')
    h1_short, _ = momentum_analysis(h1, 'SHORT')
    if h1_long:
        long_score += 5
        long_reasons.append('1H Entry-Momentum positiv')
    if h1_short:
        short_score += 5
        short_reasons.append('1H Entry-Momentum negativ')
    if macd_crossover(daily, 'LONG'):
        long_score += 10
        long_reasons.append('MACD kreuzt nach oben')
    if macd_crossover(daily, 'SHORT'):
        short_score += 10
        short_reasons.append('MACD kreuzt nach unten')
    if volume_confirmation(daily):
        if long_score > short_score:
            long_score += 10
            long_reasons.append('Volumen bestätigt')
        elif short_score > long_score:
            short_score += 10
            short_reasons.append('Volumen bestätigt')
    if use_news:
        news_intelligence = news_intelligence or {'company': news_items or [], 'sector': [], 'global': []}
        long_news = score_news_intelligence(news_intelligence, 'LONG', ticker)
        short_news = score_news_intelligence(news_intelligence, 'SHORT', ticker)
    else:
        news_intelligence = {'company': [], 'sector': [], 'global': []}
        long_news = {'total': 0, 'company': 0, 'sector': 0, 'global': 0, 'company_label': 'nicht berechnet', 'sector_label': 'nicht berechnet', 'global_label': 'nicht berechnet', 'events': [], 'net_impact': 0}
        short_news = dict(long_news)
    pattern_long = summarize_candlestick_patterns(daily, 'LONG')
    pattern_short = summarize_candlestick_patterns(daily, 'SHORT')
    technical_long = int(round(long_score * 0.7)) + int(round(pattern_long['score'] * 0.1))
    technical_short = int(round(short_score * 0.7)) + int(round(pattern_short['score'] * 0.1))
    if use_news:
        long_total = min(100, technical_long + long_news['total'])
        short_total = min(100, technical_short + short_news['total'])
    else:
        long_total = int(np.clip(round(technical_long / 80.0 * 100.0), 0, 100))
        short_total = int(np.clip(round(technical_short / 80.0 * 100.0), 0, 100))
    if long_total > short_total:
        direction = 'LONG'
        score = long_total
        reasons = long_reasons + ([f"News: Unternehmen {long_news['company']}/10 · Sektor {long_news['sector']}/5 · Global/Makro {long_news['global']}/5"] if use_news else ['News: noch nicht berechnet'])
    elif short_total > long_total:
        direction = 'SHORT'
        score = short_total
        reasons = short_reasons + ([f"News: Unternehmen {short_news['company']}/10 · Sektor {short_news['sector']}/5 · Global/Makro {short_news['global']}/5"] if use_news else ['News: noch nicht berechnet'])
    else:
        direction = 'NEUTRAL'
        score = max(long_total, short_total)
        reasons = []
    return {'direction': direction, 'score': score, 'grade': setup_grade(score), 'long_score': long_total, 'short_score': short_total, 'technical_long_score': technical_long, 'technical_short_score': technical_short, 'pattern_long_score': int(round(pattern_long['score'] * 0.1)), 'pattern_short_score': int(round(pattern_short['score'] * 0.1)), 'candlestick_patterns_long': pattern_long['patterns'], 'candlestick_patterns_short': pattern_short['patterns'], 'long_news_score': long_news['total'], 'short_news_score': short_news['total'], 'news_company': long_news['company'] if direction == 'LONG' else short_news['company'], 'news_sector': long_news['sector'] if direction == 'LONG' else short_news['sector'], 'news_global': long_news['global'] if direction == 'LONG' else short_news['global'], 'news_label': long_news['company_label'] + ' / ' + long_news['sector_label'] + ' / ' + long_news['global_label'] if direction == 'LONG' else short_news['company_label'] + ' / ' + short_news['sector_label'] + ' / ' + short_news['global_label'], 'news_impact_events': long_news.get('events', []) if direction == 'LONG' else short_news.get('events', []), 'news_net_impact': long_news.get('net_impact', 0) if direction == 'LONG' else short_news.get('net_impact', 0), 'news_calculated': bool(use_news), 'reasons': reasons, 'weekly_trend': weekly_trend['trend'], 'daily_trend': daily_trend['trend'], 'structure': structure['direction']}

def perfect_entry_signal(data, direction, plan=None):
    """Strenge Entry-Gates: Setup-Score plus technische Bestätigung."""
    if not data or direction not in ('LONG', 'SHORT'):
        return {'ready': False, 'score': 0, 'reasons': [], 'checks': []}
    daily = data.get('Daily')
    h1 = data.get('1H')
    h4 = data.get('4H')
    weekly = data.get('Weekly')
    if daily is None or daily.empty or h1 is None or h1.empty:
        return {'ready': False, 'score': 0, 'reasons': [], 'checks': []}
    if direction == 'LONG':
        trend_ok = weekly is not None and (not weekly.empty) and (trend_analysis(weekly)['trend'] == 'BULLISH') and (trend_analysis(daily)['trend'] == 'BULLISH')
    else:
        trend_ok = weekly is not None and (not weekly.empty) and (trend_analysis(weekly)['trend'] == 'BEARISH') and (trend_analysis(daily)['trend'] == 'BEARISH')
    structure_ok = market_structure(daily)['direction'] == ('BULLISH' if direction == 'LONG' else 'BEARISH')
    pullback_ok = detect_pullback(daily, direction)
    breakout_ok = detect_breakout(daily, direction)
    h4_ok, _ = momentum_analysis(h4, direction) if h4 is not None and (not h4.empty) else (False, 0)
    h1_ok, _ = momentum_analysis(h1, direction)
    volume_ok = volume_confirmation(daily)
    macd_ok = macd_crossover(daily, direction)
    adx_ok = adx_confirmation(daily, direction)
    atr_ok = atr_regime_confirmation(daily)
    candle_ok = candle_confirmation(daily, direction)
    distance_ok = entry_distance_confirmation(daily, direction)
    rr_ok = reward_risk_confirmation(plan, 2.0)
    room_ok = room_to_target_confirmation(plan, direction, 2.0)
    news_calculated = bool(data.get('NewsCalculated', False))
    news_items = data.get('News', []) or []
    news_intelligence = data.get('NewsIntelligence', {'company': news_items, 'sector': [], 'global': []})
    news_breakdown = score_news_intelligence(news_intelligence, direction, data.get('Ticker', '')) if news_calculated else {'total': 0, 'company': 0, 'sector': 0, 'global': 0, 'events': [], 'net_impact': 0}
    pattern_summary = summarize_candlestick_patterns(daily, direction)
    pattern_ok = any((p['bias'] == direction for p in pattern_summary['patterns'][:5]))
    setup_trigger_ok = pullback_ok or breakout_ok
    news_ok = news_calculated and news_breakdown['total'] >= 7
    earnings_intel = fetch_earnings_intelligence(data.get('Ticker', '')) if data.get('Ticker') else {}
    dte = _metric_num(earnings_intel.get('days_to_earnings')) if earnings_intel else np.nan
    earnings_ok = True if np.isnan(dte) else dte > EARNINGS_RISK_DAYS
    checks = [trend_ok, structure_ok, setup_trigger_ok, h4_ok, h1_ok, volume_ok, macd_ok, adx_ok, atr_ok, candle_ok, distance_ok, rr_ok, room_ok, pattern_ok, news_ok, earnings_ok]
    labels = ['Weekly + Daily Trend ausgerichtet', 'Marktstruktur bestätigt', 'Pullback ODER Breakout bestätigt', '4H Momentum bestätigt', '1H Entry-Momentum bestätigt', 'Volumen bestätigt', 'MACD-Kreuzung bestätigt', 'ADX ≥ 20: Trend stark genug', 'ATR-Regime geeignet', 'Breakout-Kerze bestätigt', 'Entry nicht überdehnt', 'CRV ≥ 2,0', 'Platz bis zum nächsten S/R-Level ≥ 2R', 'Candlestick-Muster unterstützt die Richtung', 'News-Score ≥ 7/20: keine klar adverse Nachrichtenlage' if news_calculated else 'News berechnet: Voraussetzung für ENTRY BESTÄTIGT', f'Keine Earnings in den nächsten {EARNINGS_RISK_DAYS} Tagen']
    reasons = [('✓ ' if ok else '✗ ') + label for ok, label in zip(checks, labels)]
    return {'ready': all(checks), 'score': int(sum(checks) / len(checks) * 100), 'reasons': reasons, 'checks': checks, 'labels': labels, 'pullback_ok': pullback_ok, 'breakout_ok': breakout_ok, 'earnings_risk_days': earnings_intel.get('days_to_earnings') if earnings_intel else np.nan}

def check_stop_loss_alert(current_price, stop_price, direction):
    """Liefert True, sobald der aktuelle Kurs die SL-Schwelle erreicht/überschritten hat."""
    price = safe_float(current_price)
    stop = safe_float(stop_price)
    if np.isnan(price) or np.isnan(stop) or direction not in ('LONG', 'SHORT'):
        return False
    return price <= stop if direction == 'LONG' else price >= stop

def calculate_support_resistance(df, lookback=30):
    if df is None or len(df) < 10:
        return (np.nan, np.nan)
    subset = df.iloc[-min(lookback, len(df)):]
    support = safe_float(subset['Low'].min())
    resistance = safe_float(subset['High'].max())
    return (support, resistance)

def create_trade_plan(daily, direction, atr_multiplier=1.5, risk_reward_1=2.0, risk_reward_2=3.0):
    if daily is None or daily.empty:
        return None
    row = daily.iloc[-1]
    entry = safe_float(row['Close'])
    atr = safe_float(row['ATR'])
    if np.isnan(entry):
        return None
    if np.isnan(atr) or atr <= 0:
        atr = entry * 0.02
    support, resistance = calculate_support_resistance(daily, 30)
    if direction == 'LONG':
        atr_stop = entry - atr * atr_multiplier
        if not np.isnan(support):
            structure_stop = support - atr * 0.2
            stop = min(atr_stop, structure_stop)
        else:
            stop = atr_stop
        risk = entry - stop
        if risk <= 0:
            return None
        tp1 = entry + risk * risk_reward_1
        tp2 = entry + risk * risk_reward_2
    elif direction == 'SHORT':
        atr_stop = entry + atr * atr_multiplier
        if not np.isnan(resistance):
            structure_stop = resistance + atr * 0.2
            stop = max(atr_stop, structure_stop)
        else:
            stop = atr_stop
        risk = stop - entry
        if risk <= 0:
            return None
        tp1 = entry - risk * risk_reward_1
        tp2 = entry - risk * risk_reward_2
    else:
        return None
    return {'entry': entry, 'stop': stop, 'tp1': tp1, 'tp2': tp2, 'risk_per_unit': risk, 'support': support, 'resistance': resistance, 'crv_tp1': risk_reward_1, 'crv_tp2': risk_reward_2}

def calculate_position_size(account_size, risk_percent, entry, stop):
    if account_size <= 0 or risk_percent <= 0:
        return (0, 0, 0)
    risk_money = account_size * risk_percent / 100
    risk_per_unit = abs(entry - stop)
    if risk_per_unit <= 0:
        return (0, 0, 0)
    quantity = math.floor(risk_money / risk_per_unit)
    capital = quantity * entry
    return (quantity, capital, risk_money)

def calculate_heikin_ashi(df):
    """Erzeugt Heikin-Ashi-Kerzen aus OHLC-Daten."""
    if df is None or df.empty:
        return None
    ha = pd.DataFrame(index=df.index)
    ha['Close'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4
    ha['Open'] = 0.0
    ha.iloc[0, ha.columns.get_loc('Open')] = (df['Open'].iloc[0] + df['Close'].iloc[0]) / 2
    for i in range(1, len(ha)):
        ha.iloc[i, ha.columns.get_loc('Open')] = (ha['Open'].iloc[i - 1] + ha['Close'].iloc[i - 1]) / 2
    ha['High'] = pd.concat([df['High'], ha['Open'], ha['Close']], axis=1).max(axis=1)
    ha['Low'] = pd.concat([df['Low'], ha['Open'], ha['Close']], axis=1).min(axis=1)
    return ha

def build_chart(df, ticker, timeframe, trade_plan=None, chart_type='Candlestick', show_sma20=True, show_sma50=True, show_sma200=True, show_levels=True, show_volume=True, show_rsi=True):
    if df is None or df.empty:
        return None
    df = df.copy()
    chart_df = df.tail(350)
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.025, row_heights=[0.6, 0.2, 0.2], subplot_titles=[chart_title if 'chart_title' in locals() else f'{ticker} — {timeframe}', 'Volumen', 'RSI'])
    if chart_type == 'Heikin Ashi':
        display_df = calculate_heikin_ashi(chart_df)
        chart_title = f'{ticker} — {timeframe} — Heikin Ashi'
        fig.add_trace(go.Candlestick(x=display_df.index, open=display_df['Open'], high=display_df['High'], low=display_df['Low'], close=display_df['Close'], name='Heikin Ashi', increasing_line_color='#2f6fed', decreasing_line_color='#6b7c90', increasing_fillcolor='#dce9f8', decreasing_fillcolor='#cbd3dd'), row=1, col=1)
    elif chart_type == 'Linie':
        chart_title = f'{ticker} — {timeframe} — Linie'
        fig.add_trace(go.Scatter(x=chart_df.index, y=chart_df['Close'], mode='lines', name='Schlusskurs', line=dict(color='#2f6fed', width=2.5)), row=1, col=1)
    elif chart_type == 'OHLC':
        chart_title = f'{ticker} — {timeframe} — OHLC'
        fig.add_trace(go.Ohlc(x=chart_df.index, open=chart_df['Open'], high=chart_df['High'], low=chart_df['Low'], close=chart_df['Close'], name='OHLC', increasing_line_color='#2f6fed', decreasing_line_color='#6b7c90'), row=1, col=1)
    else:
        chart_title = f'{ticker} — {timeframe} — Candlestick'
        fig.add_trace(go.Candlestick(x=chart_df.index, open=chart_df['Open'], high=chart_df['High'], low=chart_df['Low'], close=chart_df['Close'], name='Kurs', increasing_line_color='#2f6fed', decreasing_line_color='#6b7c90', increasing_fillcolor='#dce9f8', decreasing_fillcolor='#cbd3dd'), row=1, col=1)
    if show_sma20 and 'SMA20' in chart_df.columns:
        fig.add_trace(go.Scatter(x=chart_df.index, y=chart_df['SMA20'], mode='lines', name='SMA 20', line=dict(color='#6b7c90', width=1.5)), row=1, col=1)
    if show_sma50 and 'SMA50' in chart_df.columns:
        fig.add_trace(go.Scatter(x=chart_df.index, y=chart_df['SMA50'], mode='lines', name='SMA 50', line=dict(color='#2f6fed', width=1.8)), row=1, col=1)
    if show_sma200 and 'SMA200' in chart_df.columns:
        fig.add_trace(go.Scatter(x=chart_df.index, y=chart_df['SMA200'], mode='lines', name='SMA 200', line=dict(color='#23466f', width=2)), row=1, col=1)
    if show_levels and trade_plan is not None:
        colors = {'entry': '#2f6fed', 'stop': '#6b7c90', 'tp1': '#255dcc', 'tp2': '#23466f'}
        labels = {'entry': 'ENTRY', 'stop': 'STOP', 'tp1': 'TP1', 'tp2': 'TP2'}
        for key in ['entry', 'stop', 'tp1', 'tp2']:
            value = trade_plan.get(key)
            if value is None:
                continue
            fig.add_hline(y=value, line_dash='dash', line_color=colors[key], line_width=1.5, annotation_text=labels[key], annotation_position='top left', row=1, col=1)
        support = safe_float(trade_plan.get('support'))
        resistance = safe_float(trade_plan.get('resistance'))
        if not np.isnan(support):
            fig.add_hline(y=support, line_dash='dot', line_color='#6b7c90', annotation_text='Support', row=1, col=1)
        if not np.isnan(resistance):
            fig.add_hline(y=resistance, line_dash='dot', line_color='#91a1b4', annotation_text='Resistance', row=1, col=1)
    if show_volume:
        volume_colors = np.where(chart_df['Close'] >= chart_df['Open'], '#93c5fd', '#b5c0cc')
        fig.add_trace(go.Bar(x=chart_df.index, y=chart_df['Volume'], name='Volumen', marker_color=volume_colors, opacity=0.75), row=2, col=1)
    if show_rsi and 'RSI' in chart_df.columns:
        fig.add_trace(go.Scatter(x=chart_df.index, y=chart_df['RSI'], mode='lines', name='RSI', line=dict(color='#2f6fed', width=2)), row=3, col=1)
        for level, color, dash in [(70, '#91a1b4', 'dash'), (50, '#b5c0cc', 'dot'), (30, '#91a1b4', 'dash')]:
            fig.add_hline(y=level, line_dash=dash, line_color=color, row=3, col=1)
    fig.update_layout(height=800, template='plotly_white', paper_bgcolor='#edf1f5', plot_bgcolor='#edf1f5', hovermode='x unified', xaxis_rangeslider_visible=False, margin=dict(l=35, r=25, t=65, b=25), legend=dict(orientation='h', yanchor='bottom', y=1.01, xanchor='left', x=0, font=dict(color='#53657a')))
    fig.update_xaxes(showgrid=True, gridcolor='#cbd3dd')
    fig.update_yaxes(showgrid=True, gridcolor='#cbd3dd')
    fig.update_yaxes(title_text='Preis', title_font=dict(color='#6b7c90'), row=1, col=1)
    fig.update_yaxes(title_text='Volumen', title_font=dict(color='#6b7c90'), row=2, col=1)
    fig.update_yaxes(title_text='RSI', title_font=dict(color='#6b7c90'), range=[0, 100], row=3, col=1)
    return fig
JOURNAL_COLUMNS = ['Datum', 'Ticker', 'Richtung', 'Setup', 'Score', 'Entry', 'Stop', 'TP1', 'TP2', 'Ergebnis_R', 'Status', 'Kommentar']

def load_journal():
    if not os.path.exists(JOURNAL_FILE):
        return pd.DataFrame(columns=JOURNAL_COLUMNS)
    try:
        df = pd.read_csv(JOURNAL_FILE)
        for column in JOURNAL_COLUMNS:
            if column not in df.columns:
                df[column] = ''
        return df[JOURNAL_COLUMNS]
    except Exception:
        return pd.DataFrame(columns=JOURNAL_COLUMNS)

def save_journal(df):
    df.to_csv(JOURNAL_FILE, index=False)

def backtest_strategy(df, direction='LONG', risk_percent=1.0, initial_capital=10000, atr_multiplier=1.5, reward_ratio=2.0):
    if df is None:
        return None
    if len(df) < 250:
        return None
    data = df.copy()
    capital = float(initial_capital)
    equity = []
    trades = []
    position = None
    for i in range(200, len(data)):
        row = data.iloc[i]
        date = data.index[i]
        open_price = safe_float(row['Open'])
        close = safe_float(row['Close'])
        high = safe_float(row['High'])
        low = safe_float(row['Low'])
        atr = safe_float(row['ATR'])
        sma50 = safe_float(row['SMA50'])
        sma200 = safe_float(row['SMA200'])
        rsi = safe_float(row['RSI'])
        ema20 = safe_float(row['EMA20'])
        adx = safe_float(row.get('ADX'))
        macd = safe_float(row.get('MACD'))
        macd_signal = safe_float(row.get('MACDSignal'))
        if any((np.isnan(x) for x in [open_price, close, high, low, atr, sma50, sma200, rsi, ema20])):
            equity.append({'Date': date, 'Equity': capital})
            continue
        if position is not None:
            exit_price = None
            exit_reason = None
            if position['direction'] == 'LONG':
                stop_hit = low <= position['stop']
                target_hit = high >= position['target']
            else:
                stop_hit = high >= position['stop']
                target_hit = low <= position['target']
            if stop_hit:
                exit_price = position['stop']
                exit_reason = 'STOP'
            elif target_hit:
                exit_price = position['target']
                exit_reason = 'TARGET'
            if exit_price is not None:
                if position['direction'] == 'LONG':
                    pnl_per_unit = exit_price - position['entry']
                else:
                    pnl_per_unit = position['entry'] - exit_price
                pnl = pnl_per_unit * position['quantity']
                capital += pnl
                risk_money = position['risk_money']
                r_multiple = pnl / risk_money if risk_money > 0 else 0
                trades.append({'Entry Date': position['date'], 'Exit Date': date, 'Direction': position['direction'], 'Entry': position['entry'], 'Exit': exit_price, 'Stop': position['stop'], 'Target': position['target'], 'Quantity': position['quantity'], 'PnL': pnl, 'R': r_multiple, 'Reason': exit_reason, 'Equity': capital})
                position = None
        if position is None and i > 200:
            previous = data.iloc[i - 1]
            previous_close = safe_float(previous['Close'])
            previous_ema = safe_float(previous['EMA20'])
            previous_sma50 = safe_float(previous['SMA50'])
            previous_sma200 = safe_float(previous['SMA200'])
            previous_rsi = safe_float(previous['RSI'])
            previous_adx = safe_float(previous.get('ADX'))
            previous_macd = safe_float(previous.get('MACD'))
            previous_macd_signal = safe_float(previous.get('MACDSignal'))
            if not any((np.isnan(x) for x in [previous_close, previous_ema, previous_sma50, previous_sma200, previous_rsi, previous_adx, previous_macd, previous_macd_signal])):
                long_signal = previous_close > previous_sma200 and previous_sma50 > previous_sma200 and (previous_close > previous_sma50) and (50 <= previous_rsi <= 70) and (previous_close > previous_ema) and (previous_adx >= 20) and (previous_macd > previous_macd_signal)
                short_signal = previous_close < previous_sma200 and previous_sma50 < previous_sma200 and (previous_close < previous_sma50) and (30 <= previous_rsi <= 50) and (previous_close < previous_ema) and (previous_adx >= 20) and (previous_macd < previous_macd_signal)
                signal = long_signal if direction == 'LONG' else short_signal
                if signal:
                    entry = open_price
                    risk_money = capital * risk_percent / 100
                    if direction == 'LONG':
                        stop = entry - atr * atr_multiplier
                        risk_per_unit = entry - stop
                        target = entry + risk_per_unit * reward_ratio
                    else:
                        stop = entry + atr * atr_multiplier
                        risk_per_unit = stop - entry
                        target = entry - risk_per_unit * reward_ratio
                    if risk_per_unit > 0:
                        quantity = math.floor(risk_money / risk_per_unit)
                        if quantity > 0:
                            position = {'date': date, 'direction': direction, 'entry': entry, 'stop': stop, 'target': target, 'quantity': quantity, 'risk_money': risk_money}
        equity.append({'Date': date, 'Equity': capital})
    equity_df = pd.DataFrame(equity)
    trades_df = pd.DataFrame(trades)
    if equity_df.empty:
        return None
    if not trades_df.empty:
        winners = trades_df[trades_df['PnL'] > 0]
        losers = trades_df[trades_df['PnL'] < 0]
        winrate = len(winners) / len(trades_df) * 100
        gross_profit = winners['PnL'].sum()
        gross_loss = abs(losers['PnL'].sum())
        if gross_loss > 0:
            profit_factor = gross_profit / gross_loss
        else:
            profit_factor = np.inf
        average_r = trades_df['R'].mean()
    else:
        winrate = 0
        profit_factor = 0
        average_r = 0
    equity_series = equity_df['Equity']
    running_max = equity_series.cummax()
    drawdown = (equity_series - running_max) / running_max * 100
    max_drawdown = drawdown.min()
    final_capital = equity_series.iloc[-1]
    total_return = (final_capital / initial_capital - 1) * 100
    return {'trades': trades_df, 'equity': equity_df, 'initial_capital': initial_capital, 'final_capital': final_capital, 'total_return': total_return, 'winrate': winrate, 'profit_factor': profit_factor, 'average_r': average_r, 'max_drawdown': max_drawdown}

def walk_forward_validation(df, direction='LONG', risk_percent=1.0, initial_capital=10000, atr_multiplier=1.5, reward_ratio=2.0, windows=4):
    """Einfaches Walk-Forward/OOS-Modell: mehrere zeitlich getrennte Out-of-Sample-Fenster."""
    if df is None or len(df) < 800:
        return None
    n = len(df)
    test_size = max(100, n // (windows + 1))
    rows = []
    for w in range(windows):
        train_end = n - (windows - w) * test_size
        test_end = min(n, train_end + test_size)
        if train_end < 250 or test_end - train_end < 80:
            continue
        test = df.iloc[train_end:test_end].copy()
        r = backtest_strategy(test, direction=direction, risk_percent=risk_percent, initial_capital=initial_capital, atr_multiplier=atr_multiplier, reward_ratio=reward_ratio)
        if r is None:
            continue
        rows.append({'Fenster': w + 1, 'OOS von': str(test.index[0].date()), 'OOS bis': str(test.index[-1].date()), 'Trades': len(r['trades']), 'Rendite %': r['total_return'], 'Winrate %': r['winrate'], 'Profit Factor': r['profit_factor'], 'Max DD %': r['max_drawdown'], 'Ø R': r['average_r']})
    return pd.DataFrame(rows) if rows else None

def recalculate_news_for_existing_scan(minimum_score, atr_multiplier, account_size, risk_percent):
    """Berechnet News ausschließlich als Zusatzinformation.

    WICHTIG: Der bereits abgeschlossene technische Scan ist die Quelle der Wahrheit.
    News dürfen weder Kandidaten entfernen noch den technischen Score/Filter verändern.
    """
    existing = st.session_state.get('market_data', {})
    existing_df = st.session_state.get('scan_results', pd.DataFrame()).copy()
    if not existing or existing_df.empty:
        return (False, 'Noch kein Scan mit Ergebnissen vorhanden.')
    progress = st.progress(0, text='News-Analyse startet...')
    try:
        global_news = fetch_global_news()
    except Exception as error:
        global_news = []
        st.session_state.scan_errors = [f'Globale News: {error}']
    new_market_data = dict(existing)
    errors = list(st.session_state.get('scan_errors', []))
    news_by_ticker = {}
    items = [(ticker, existing.get(ticker, {})) for ticker in existing_df['Ticker'].astype(str).tolist() if ticker in existing]
    for idx, (ticker, old_record) in enumerate(items):
        progress.progress((idx + 1) / max(len(items), 1), text=f'News analysiert: {ticker}...')
        try:
            data = dict(old_record.get('data', {}))
            setup = dict(old_record.get('setup', {}))
            daily = data.get('Daily')
            if daily is None or daily.empty:
                continue
            news_items = fetch_ticker_news(ticker, NEWS_LOOKBACK)
            news_intelligence = build_news_intelligence(ticker, news_items, global_news)
            direction = setup.get('direction', 'LONG')
            news_score = score_news_intelligence(news_intelligence, direction, ticker)
            enriched_data = dict(data)
            enriched_data.update({'News': news_items, 'NewsIntelligence': news_intelligence, 'GlobalNews': global_news, 'Ticker': ticker, 'NewsCalculated': True})
            record = dict(old_record)
            record.update({'data': enriched_data, 'news': news_items, 'NewsIntelligence': news_intelligence, 'GlobalNews': global_news, 'NewsCalculated': True})
            new_market_data[ticker] = record
            news_by_ticker[ticker] = {'News': setup.get('news_label', 'Keine Newsbewertung') if not news_items else setup.get('news_label', 'News vorhanden'), 'News Punkte': news_score.get('total', 0), 'Unternehmen News': news_score.get('company', 0), 'Sektor News': news_score.get('sector', 0), 'Global News': news_score.get('global', 0), 'News Impact': news_score.get('net_impact', 0), 'News Anzahl': len(news_items)}
        except Exception as error:
            errors.append(f'{ticker} News: {error}')
            news_by_ticker[ticker] = {'News': 'Nicht verfügbar', 'News Punkte': 0, 'Unternehmen News': 0, 'Sektor News': 0, 'Global News': 0, 'News Impact': 0, 'News Anzahl': 0}
    progress.empty()
    result_df = existing_df.copy()
    for ticker, news_values in news_by_ticker.items():
        mask = result_df['Ticker'].astype(str) == ticker
        for column, value in news_values.items():
            result_df.loc[mask, column] = value
    result_df = result_df.reset_index(drop=True)
    st.session_state.scan_results = result_df
    st.session_state.market_data = new_market_data
    st.session_state.scan_errors = errors
    st.session_state.global_news_count = len(global_news)
    st.session_state.news_calculated = True
    st.session_state.scan_time = datetime.now().strftime('%d.%m.%Y %H:%M:%S')
    return (True, f'News-Berechnung abgeschlossen: {len(result_df)} gefundene Aktien bleiben sichtbar. News dienen nur als Information.')

def _technical_scan_worker(ticker, data, max_price, minimum_score, atr_multiplier):
    """Berechnet die identische technische Analyse parallel je Ticker."""
    try:
        if data is None:
            return (None, None)
        daily = data.get('Daily')
        if daily is None or daily.empty:
            return (None, None)
        price = safe_float(daily['Close'].iloc[-1])
        if np.isnan(price) or price > max_price:
            return (None, None)
        setup = analyze_setup(data, [], {'company': [], 'sector': [], 'global': []}, ticker=ticker, use_news=False)
        if setup is None or setup['score'] < minimum_score or setup['direction'] == 'NEUTRAL':
            return (None, None)
        plan = create_trade_plan(daily, setup['direction'], atr_multiplier)
        if plan is None:
            return (None, None)
        return ({'ticker': ticker, 'data': data, 'daily': daily, 'price': price, 'setup': setup, 'plan': plan}, None)
    except Exception as exc:
        return (None, f'{ticker}: {exc}')

def _fundamental_intelligence_worker(ticker):
    """Lädt Fundamentaldaten und Market Intelligence parallel; Cache bleibt aktiv."""
    try:
        fundamentals = build_fundamental_snapshot(ticker)
        market_intel = build_market_intelligence(ticker, fundamentals)
        return (fundamentals, market_intel, None)
    except Exception as exc:
        return ({}, {'score': 50, 'earnings': {}, 'relative_strength': {'score': 50, 'benchmark': DEFAULT_BENCHMARK}}, f'{ticker}: {exc}')

def run_scan(selected_markets, max_price=500.0, minimum_score=70,
             atr_multiplier=1.5, account_size=10000.0, risk_percent=1.0):
    """Headless version of the V8 technical + fundamentals scan for the Android API."""
    if not selected_markets:
        raise ValueError("Mindestens ein Markt muss ausgewählt werden.")

    dynamic_markets, universe_errors = get_market_universe(selected_markets)
    all_tickers = list(dict.fromkeys(
        ticker
        for market_name in selected_markets
        for ticker in dynamic_markets.get(market_name, [])
    ))
    if not all_tickers:
        raise RuntimeError("Es konnten keine Aktien für die ausgewählten Märkte geladen werden.")

    results = []
    market_data = {}
    errors = list(universe_errors)

    try:
        loaded_data = load_all_timeframes_batch(all_tickers)
    except Exception as error:
        errors.append(f"Batch-Download: {error}")
        loaded_data = {}
        with ThreadPoolExecutor(max_workers=SCAN_DOWNLOAD_WORKERS) as executor:
            future_map = {executor.submit(load_all_timeframes, t): t for t in all_tickers}
            for future in as_completed(future_map):
                ticker = future_map[future]
                try:
                    loaded_data[ticker] = future.result()
                except Exception as exc:
                    errors.append(f"{ticker}: {exc}")
                except BaseException as exc:
                    errors.append(f"{ticker}: {exc}")

    candidates = []
    with ThreadPoolExecutor(max_workers=SCAN_INDICATOR_WORKERS) as executor:
        future_map = {
            executor.submit(
                _technical_scan_worker, ticker, loaded_data.get(ticker),
                max_price, minimum_score, atr_multiplier
            ): ticker
            for ticker in all_tickers
        }
        for future in as_completed(future_map):
            ticker = future_map[future]
            try:
                candidate, err = future.result()
                if err:
                    errors.append(err)
                if candidate is not None:
                    candidates.append(candidate)
            except Exception as exc:
                errors.append(f"{ticker}: {exc}")

    candidates.sort(key=lambda x: x["ticker"])
    enrichment = {}
    if candidates:
        with ThreadPoolExecutor(max_workers=SCAN_INDICATOR_WORKERS) as executor:
            future_map = {
                executor.submit(_fundamental_intelligence_worker, c["ticker"]): c["ticker"]
                for c in candidates
            }
            for future in as_completed(future_map):
                ticker = future_map[future]
                try:
                    fundamentals, market_intel, err = future.result()
                    enrichment[ticker] = (fundamentals, market_intel)
                    if err:
                        errors.append(err)
                except Exception as exc:
                    enrichment[ticker] = ({}, {
                        "score": 50,
                        "earnings": {},
                        "relative_strength": {"score": 50, "benchmark": DEFAULT_BENCHMARK},
                    })
                    errors.append(f"{ticker}: {exc}")

    for candidate in candidates:
        ticker = candidate["ticker"]
        data = candidate["data"]
        daily = candidate["daily"]
        price = candidate["price"]
        setup = candidate["setup"]
        plan = candidate["plan"]

        try:
            fundamentals, market_intel = enrichment.get(
                ticker, ({}, {
                    "score": 50,
                    "earnings": {},
                    "relative_strength": {"score": 50, "benchmark": DEFAULT_BENCHMARK},
                })
            )
            entry_check = perfect_entry_signal(
                {**data, "News": [], "NewsIntelligence": {
                    "company": [], "sector": [], "global": []
                }, "Ticker": ticker},
                setup["direction"], plan
            )
            match_count = int(sum(entry_check.get("checks", [])))
            match_total = int(len(entry_check.get("checks", [])))
            quantity, capital, risk_money = calculate_position_size(
                account_size, risk_percent, plan["entry"], plan["stop"]
            )

            results.append({
                "Ticker": ticker,
                "Richtung": setup["direction"],
                "Score": float(setup["score"]),
                "Übereinstimmungen": match_count,
                "Prüfkriterien": match_total,
                "Perfekter Einstieg": "JA" if entry_check.get("ready") else "NEIN",
                "Entry Match %": float(entry_check.get("score", 0)),
                "News": "Nicht berechnet",
                "News Punkte": float(
                    setup["long_news_score"]
                    if setup["direction"] == "LONG"
                    else setup["short_news_score"]
                ),
                "Fundamental Score": fundamentals.get("assessment", {}).get("score"),
                "Marktkapitalisierung": _metric_num(fundamentals.get("metrics", {}).get("marketCap")),
                "KGV": _metric_num(fundamentals.get("metrics", {}).get("trailingPE")),
                "Forward KGV": _metric_num(fundamentals.get("metrics", {}).get("forwardPE")),
                "PEG": _metric_num(fundamentals.get("metrics", {}).get("pegRatio")),
                "KUV": _metric_num(fundamentals.get("metrics", {}).get("priceToSalesTrailing12Months")),
                "KBV": _metric_num(fundamentals.get("metrics", {}).get("priceToBook")),
                "EV/EBITDA": _metric_num(fundamentals.get("metrics", {}).get("enterpriseToEbitda")),
                "Umsatzwachstum": _metric_num(fundamentals.get("metrics", {}).get("revenueGrowth")),
                "Gewinnwachstum": _metric_num(fundamentals.get("metrics", {}).get("earningsGrowth")),
                "Nettomarge": _metric_num(fundamentals.get("metrics", {}).get("profitMargins")),
                "ROE": _metric_num(fundamentals.get("metrics", {}).get("returnOnEquity")),
                "Debt/Equity": _metric_num(fundamentals.get("metrics", {}).get("debtToEquity")),
                "Current Ratio": _metric_num(fundamentals.get("metrics", {}).get("currentRatio")),
                "Free Cashflow": _metric_num(fundamentals.get("metrics", {}).get("freeCashflow")),
                "Dividendenrendite": _metric_num(fundamentals.get("metrics", {}).get("dividendYield")),
                "Beta": _metric_num(fundamentals.get("metrics", {}).get("beta")),
                "Sektor": fundamentals.get("metrics", {}).get("sector") or "Unbekannt",
                "Market Intelligence": market_intel.get("score", 50),
                "Relative Strength": market_intel.get("relative_strength", {}).get("score", 50),
                "Earnings Score": market_intel.get("earnings", {}).get("earnings_score", 50),
                "Setup": setup["grade"],
                "Weekly": setup["weekly_trend"],
                "Daily": setup["daily_trend"],
                "Struktur": setup["structure"],
                "Preis": round(price, 2),
                "Entry": round(plan["entry"], 2),
                "Stop": round(plan["stop"], 2),
                "TP1": round(plan["tp1"], 2),
                "TP2": round(plan["tp2"], 2),
                "CRV": f"1:{plan['crv_tp1']:.1f}",
                "Stück": int(quantity),
                "Kapital": round(capital, 2),
                "Risiko €": round(risk_money, 2),
            })
            market_data[ticker] = {
                "setup": setup,
                "plan": plan,
                "EntryCheck": entry_check,
                "Fundamentals": fundamentals,
                "MarketIntelligence": market_intel,
                "data": data,
            }
        except Exception as exc:
            errors.append(f"{ticker}: {exc}")

    result_df = pd.DataFrame(results)
    if not result_df.empty:
        result_df = enrich_peer_comparison(result_df).sort_values(
            ["Score", "Übereinstimmungen", "Entry Match %", "Market Intelligence", "Ticker"],
            ascending=[False, False, False, False, True],
        ).reset_index(drop=True)

    # DataFrames/price history stay server-side; Android receives compact JSON only.
    return {
        "scan": {
            "markets": selected_markets,
            "max_price": max_price,
            "minimum_score": minimum_score,
            "candidate_count": int(len(result_df)),
            "universe_count": int(len(all_tickers)),
            "errors": errors[:100],
        },
        "best": result_df.iloc[0].to_dict() if not result_df.empty else None,
        "results": result_df.to_dict(orient="records") if not result_df.empty else [],
        "_market_data": market_data,
    }
