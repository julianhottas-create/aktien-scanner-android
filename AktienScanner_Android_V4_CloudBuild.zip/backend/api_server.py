
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import core

app = FastAPI(
    title="Aktien Scanner API",
    version="1.0.0",
    description="Headless API für den Swing Trading Command Center Scanner."
)

LAST_SCAN = None

class ScanRequest(BaseModel):
    markets: List[str] = Field(default_factory=lambda: [
        "🇺🇸 US Tech", "🇺🇸 US Standard", "🇩🇪 Deutschland", "🇪🇺 Europa"
    ])
    max_price: float = Field(500.0, ge=0)
    minimum_score: int = Field(70, ge=0, le=100)
    atr_multiplier: float = Field(1.5, ge=0.5, le=3.0)
    account_size: float = Field(10000.0, ge=100)
    risk_percent: float = Field(1.0, ge=0.25, le=3.0)

@app.get("/health")
def health():
    return {"status": "ok", "service": "Aktien Scanner", "version": "1.0"}

@app.get("/markets")
def markets():
    return {
        "markets": list(core.MARKETS.keys()),
        "fallback_tickers": {k: v for k, v in core.MARKETS.items()},
    }

@app.post("/scan")
def scan(req: ScanRequest):
    global LAST_SCAN
    try:
        payload = core.run_scan(
            req.markets, req.max_price, req.minimum_score,
            req.atr_multiplier, req.account_size, req.risk_percent
        )
        LAST_SCAN = payload
        payload.pop("_market_data", None)
        return payload
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.get("/last-scan")
def last_scan():
    if LAST_SCAN is None:
        raise HTTPException(status_code=404, detail="Noch kein Scan vorhanden.")
    return LAST_SCAN
