# Schritt 5 – Online-Betrieb

Ziel:
Android-App → HTTPS → Scanner-API → Marktdaten → Ergebnis → Android-App

## Hosting
Das Projekt ist für Render vorbereitet (`render.yaml`).

Render unterstützt FastAPI-Webservices direkt. Beim Erstellen des Web Service werden
Build- und Start-Befehl aus der Konfiguration verwendet.

## Was noch benötigt wird
1. Ein GitHub-Repository mit diesem Projekt.
2. Das Repository mit Render verbinden.
3. Web Service deployen.
4. Die erzeugte `https://...onrender.com` URL in der Android-App bei
   "Scanner API URL" eintragen.

Danach kann die Android-App den Scanner über das Internet erreichen.

## Sicherheits-Hinweis
Vor einem öffentlichen Produktivbetrieb sollten API-Schutz, Rate-Limiting und ggf.
Authentifizierung ergänzt werden.
