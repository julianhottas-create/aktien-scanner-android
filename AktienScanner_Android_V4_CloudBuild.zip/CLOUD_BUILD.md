# APK Cloud Build

Dieses Projekt enthält `.github/workflows/build-apk.yml`.

Nach dem Hochladen auf GitHub:
1. Repository öffnen.
2. Tab `Actions` öffnen.
3. Workflow `Build Android APK` auswählen.
4. `Run workflow` drücken.
5. Nach Abschluss unter `Artifacts` die APK `aktien-scanner-release-apk` herunterladen.

Wichtig:
- Die APK wird in GitHub Actions gebaut.
- Dafür ist kein eigener PC mit Android Studio erforderlich.
- Vor dem echten Scan muss die API-URL in der App auf die tatsächlich deployte HTTPS-API zeigen.
