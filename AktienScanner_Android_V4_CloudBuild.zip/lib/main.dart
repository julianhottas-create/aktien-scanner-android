import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const AktienScannerApp());

class ApiService {
  String baseUrl;
  ApiService(this.baseUrl);

  Future<bool> health() async {
    final r = await http.get(Uri.parse('$baseUrl/health')).timeout(const Duration(seconds: 15));
    return r.statusCode == 200;
  }

  Future<List<String>> markets() async {
    final r = await http.get(Uri.parse('$baseUrl/markets')).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw Exception('Markets: HTTP ${r.statusCode}');
    final j = jsonDecode(r.body);
    return List<String>.from(j['markets'] ?? []);
  }

  Future<Map<String, dynamic>> news(List<String> tickers) async {
    final r = await http.post(
      Uri.parse('$baseUrl/news'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'tickers': tickers}),
    ).timeout(const Duration(minutes: 3));
    if (r.statusCode != 200) throw Exception('News: HTTP ${r.statusCode}: ${r.body}');
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> scan({
    required List<String> markets,
    required double maxPrice,
    required double minimumScore,
    required double atrMultiplier,
    required double accountSize,
    required double riskPercent,
  }) async {
    final r = await http.post(
      Uri.parse('$baseUrl/scan'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'markets': markets,
        'max_price': maxPrice,
        'minimum_score': minimumScore,
        'atr_multiplier': atrMultiplier,
        'account_size': accountSize,
        'risk_percent': riskPercent,
      }),
    ).timeout(const Duration(minutes: 5));
    if (r.statusCode != 200) {
      throw Exception('Scan: HTTP ${r.statusCode}: ${r.body}');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}

class AktienScannerApp extends StatefulWidget {
  const AktienScannerApp({super.key});
  @override
  State<AktienScannerApp> createState() => _AppState();
}

class _AppState extends State<AktienScannerApp> {
  // Replace this with the URL of the hosted scanner API.
  final _url = TextEditingController(text: 'https://DEINE-SCANNER-API.onrender.com');
  final _maxPrice = TextEditingController(text: '500');
  final _minScore = TextEditingController(text: '70');
  final _atr = TextEditingController(text: '1.5');
  final _account = TextEditingController(text: '10000');
  final _risk = TextEditingController(text: '1');

  ApiService? api;
  List<String> allMarkets = [];
  final Set<String> selectedMarkets = {};
  Map<String, dynamic>? result;
  bool loading = false;
  bool newsLoading = false;
  String status = 'Noch kein Scan durchgeführt.';
  String? error;

  @override
  void dispose() {
    _url.dispose(); _maxPrice.dispose(); _minScore.dispose(); _atr.dispose();
    _account.dispose(); _risk.dispose();
    super.dispose();
  }

  Future<void> loadMarkets() async {
    try {
      api = ApiService(_url.text.trim().replaceAll(RegExp(r'/$'), ''));
      final ok = await api!.health();
      if (!ok) throw Exception('API nicht erreichbar');
      final m = await api!.markets();
      setState(() {
        allMarkets = m;
        selectedMarkets
          ..clear()
          ..addAll(m);
        status = 'API verbunden · ${m.length} Märkte verfügbar';
        error = null;
      });
    } catch (e) {
      setState(() { error = e.toString(); status = 'Verbindung fehlgeschlagen'; });
    }
  }

  Future<void> runNews() async {
    final rows = (result?['results'] as List?)?.cast<Map<String, dynamic>>() ?? [];
    final tickers = rows.map((e) => e['Ticker']?.toString() ?? '').where((e) => e.isNotEmpty).toList();
    if (tickers.isEmpty || api == null) return;
    setState(() { newsLoading = true; error = null; status = 'News werden berechnet…'; });
    try {
      final r = await api!.news(tickers);
      final news = (r['news'] as Map?)?.length ?? 0;
      setState(() { newsLoading = false; status = 'News berechnet · $news Aktien'; });
    } catch (e) {
      setState(() { newsLoading = false; error = e.toString(); status = 'News fehlgeschlagen'; });
    }
  }

  Future<void> runScan() async {
    if (api == null) {
      await loadMarkets();
      if (api == null || error != null) return;
    }
    setState(() { loading = true; error = null; status = 'Scan läuft…'; });
    try {
      final r = await api!.scan(
        markets: selectedMarkets.toList(),
        maxPrice: double.parse(_maxPrice.text),
        minimumScore: double.parse(_minScore.text),
        atrMultiplier: double.parse(_atr.text),
        accountSize: double.parse(_account.text),
        riskPercent: double.parse(_risk.text),
      );
      setState(() {
        result = r;
        status = 'Scan abgeschlossen';
        loading = false;
      });
    } catch (e) {
      setState(() { loading = false; error = e.toString(); status = 'Scan fehlgeschlagen'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aktien Scanner',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF1E2630),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3D78B8), brightness: Brightness.dark),
        useMaterial3: true,
        textTheme: const TextTheme(bodyMedium: TextStyle(color: Color(0xFFD2DAE3))),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('AKTIEN SCANNER', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(onPressed: loadMarkets, icon: const Icon(Icons.cloud_sync), tooltip: 'API verbinden'),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              _hero(),
              const SizedBox(height: 12),
              _settings(),
              const SizedBox(height: 12),
              _markets(),
              const SizedBox(height: 12),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: loading ? null : runScan,
                  icon: loading
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.radar),
                  label: Text(loading ? 'SCAN LÄUFT…' : 'AKTIEN SCANNEN'),
                ),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: (newsLoading || result == null) ? null : runNews,
                icon: newsLoading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.newspaper),
                label: Text(newsLoading ? 'NEWS LÄUFT…' : 'NEWS ANALYSIEREN'),
              ),
              const SizedBox(height: 12),
              if (error != null) _error(),
              _results(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero() {
    final best = result?['best'];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PERFEKTE AKTIE', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(best?['Ticker']?.toString() ?? '—',
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color(0xFF77B4EA))),
          const SizedBox(height: 8),
          if (best != null)
            Wrap(spacing: 8, runSpacing: 6, children: [
              _chip('Score ${best['Score'] ?? '—'}'),
              _chip('${best['Richtung'] ?? '—'}'),
              _chip('Entry ${best['Entry'] ?? '—'}'),
              _chip('SL ${best['Stop'] ?? '—'}'),
            ]),
          const SizedBox(height: 8),
          Text(status),
        ]),
      ),
    );
  }

  Widget _settings() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: _url, decoration: const InputDecoration(labelText: 'Scanner API URL', prefixIcon: Icon(Icons.link))),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _num(_maxPrice, 'Max. Preis')),
            const SizedBox(width: 8),
            Expanded(child: _num(_minScore, 'Min. Score')),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _num(_atr, 'ATR Multiplikator')),
            const SizedBox(width: 8),
            Expanded(child: _num(_account, 'Konto €')),
            const SizedBox(width: 8),
            Expanded(child: _num(_risk, 'Risiko %')),
          ]),
        ]),
      ),
    );
  }

  Widget _num(TextEditingController c, String label) => TextField(
    controller: c,
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    decoration: InputDecoration(labelText: label),
  );

  Widget _markets() {
    final markets = allMarkets.isEmpty ? ['SP500', 'NASDAQ100', 'DAX', 'EUROPE600'] : allMarkets;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MÄRKTE', style: TextStyle(fontWeight: FontWeight.bold)),
          Wrap(
            children: markets.map((m) => FilterChip(
              label: Text(m),
              selected: selectedMarkets.contains(m),
              onSelected: (v) => setState(() => v ? selectedMarkets.add(m) : selectedMarkets.remove(m)),
            )).toList(),
          ),
          const SizedBox(height: 4),
          Text('${selectedMarkets.length} Märkte ausgewählt'),
        ]),
      ),
    );
  }

  Widget _results() {
    final rows = (result?['results'] as List?)?.cast<Map<String, dynamic>>() ?? [];
    if (rows.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('ERGEBNISSE · ${rows.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...rows.take(50).map(_row),
    ]);
  }

  Widget _row(Map<String, dynamic> r) {
    return Card(
      child: ListTile(
        title: Text('${r['Ticker'] ?? '—'}  ·  ${r['Richtung'] ?? '—'}'),
        subtitle: Text('Entry ${r['Entry'] ?? '—'}  |  SL ${r['Stop'] ?? '—'}  |  TP1 ${r['TP1'] ?? '—'}  |  CRV ${r['CRV'] ?? '—'}'),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('${r['Score'] ?? '—'}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const Text('Score'),
        ]),
      ),
    );
  }

  Widget _chip(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFF3D78B8)),
    ),
    child: Text(text),
  );

  Widget _error() => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Text(error!, style: const TextStyle(color: Color(0xFFFFB4AB))),
    ),
  );
}
